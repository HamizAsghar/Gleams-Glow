<?php

require('connection.php');

function getUserIP()
{
    $IP = false;
    if (getenv('HTTP_CLIENT_IP')) {
        $IP = getenv('HTTP_CLIENT_IP');
    } else if (getenv('HTTP_X_FORWARDED_FOR')) {
        $IP = getenv('HTTP_X_FORWARDED_FOR');
    } else if (getenv('HTTP_X_FORWARDED')) {
        $IP = getenv('HTTP_X_FORWARDED');
    } else if (getenv('HTTP_FORWARDED_FOR')) {
        $IP = getenv('HTTP_FORWARDED_FOR');
    } else if (getenv('HTTP_FORWARDED')) {
        $IP = getenv('HTTP_FORWARDED');
    } else if (getenv('REMOTE_ADDR')) {
        $IP = getenv('REMOTE_ADDR');
    }

    //If HTTP_X_FORWARDED_FOR == server ip
    if ((($IP) && ($IP == getenv('SERVER_ADDR')) && (getenv('REMOTE_ADDR')) || (!filter_var($IP, FILTER_VALIDATE_IP)))) {
        $IP = getenv('REMOTE_ADDR');
    }

    if ($IP) {
        if (!filter_var($IP, FILTER_VALIDATE_IP)) {
            $IP = false;
        }
    } else {
        $IP = false;
    }
    return $IP;
}

$userIp = str_replace(['.', ':'], ['', ''], getUserIP());

$query = "SELECT c.*, 
p.title, 
p.thumbnail_image, 
p.slug, 
IF(p.discounted_price = 0, p.price, p.discounted_price) AS final_price,
COALESCE(color_name, '') AS color_name,
COALESCE(size_name, '') AS size_name
FROM cart c
INNER JOIN products p ON c.product_id = p.id 
LEFT JOIN variants AS color ON c.color_id = color.id AND color.type = 'color'
LEFT JOIN variants AS size ON c.size_id = size.id AND size.type = 'size'
WHERE c.ip_address = ?
ORDER BY c.id DESC";

$stmt = mysqli_prepare($con, $query);
mysqli_stmt_bind_param($stmt, "s", $userIp);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if ($result) {
    $cartItems = mysqli_fetch_all($result, MYSQLI_ASSOC);

    $totalSum = 0;
    foreach ($cartItems as $item) {
        $totalSum += $item['final_price'] * $item['quantity'];
    }
} else {
    $cartItems = [];
    $totalSum = 0;
}
?>

<!doctype html>
<html lang="en">

<head>

    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-159HFH84B1"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'G-159HFH84B1');
    </script>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="images/favicon.ico" type="image/x-icon" />
    <title>Checkout - Shopilic</title>

    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">

    <style>
        .bd-placeholder-img {
            font-size: 1.125rem;
            text-anchor: middle;
            -webkit-user-select: none;
            -moz-user-select: none;
            user-select: none;
        }

        @media (min-width: 768px) {
            .bd-placeholder-img-lg {
                font-size: 3.5rem;
            }
        }

        .b-example-divider {
            width: 100%;
            height: 3rem;
            background-color: rgba(0, 0, 0, .1);
            border: solid rgba(0, 0, 0, .15);
            border-width: 1px 0;
            box-shadow: inset 0 .5em 1.5em rgba(0, 0, 0, .1), inset 0 .125em .5em rgba(0, 0, 0, .15);
        }

        .b-example-vr {
            flex-shrink: 0;
            width: 1.5rem;
            height: 100vh;
        }

        .bi {
            vertical-align: -.125em;
            fill: currentColor;
        }

        .nav-scroller {
            position: relative;
            z-index: 2;
            height: 2.75rem;
            overflow-y: hidden;
        }

        .nav-scroller .nav {
            display: flex;
            flex-wrap: nowrap;
            padding-bottom: 1rem;
            margin-top: -1px;
            overflow-x: auto;
            text-align: center;
            white-space: nowrap;
            -webkit-overflow-scrolling: touch;
        }

        .btn-bd-primary {
            --bd-violet-bg: #712cf9;
            --bd-violet-rgb: 112.520718, 44.062154, 249.437846;

            --bs-btn-font-weight: 600;
            --bs-btn-color: var(--bs-white);
            --bs-btn-bg: var(--bd-violet-bg);
            --bs-btn-border-color: var(--bd-violet-bg);
            --bs-btn-hover-color: var(--bs-white);
            --bs-btn-hover-bg: #6528e0;
            --bs-btn-hover-border-color: #6528e0;
            --bs-btn-focus-shadow-rgb: var(--bd-violet-rgb);
            --bs-btn-active-color: var(--bs-btn-hover-color);
            --bs-btn-active-bg: #5a23c8;
            --bs-btn-active-border-color: #5a23c8;
        }

        .bd-mode-toggle {
            z-index: 1500;
        }

        .bd-mode-toggle .dropdown-menu .active .bi {
            display: block !important;
        }
    </style>
</head>

<body class="bg-body-tertiary">

    <div class="container" style="max-width: 960px;">
        <main class="my-5">

            <div class="row g-5">
                <div class="col-md-5 col-lg-4 order-md-last">
                    <h4 class="d-flex justify-content-between align-items-center mb-3">
                        <span class="text-primary">Your cart</span>
                        <span class="badge bg-primary rounded-pill"><?php echo count($cartItems); ?></span>
                    </h4>
                    <ul class="list-group mb-3">
                        <?php foreach ($cartItems as $item) : ?>
                            <li class="list-group-item d-flex justify-content-between lh-sm">
                                <div>
                                    <h6 class="my-0"><?php echo $item['title']; ?></h6>

                                    <div class="d-flex align-items-center fw-bold my-1">
                                        <span class="text-body-black">Rs. <?php echo $item['final_price']; ?></span>
                                        <span class="px-2 text-danger">x</span>
                                        <span class="text-body-black"><?php echo $item['quantity']; ?></span>
                                        <span class="px-2 text-danger">=</span>
                                        <span class="text-body-black">Rs. <?php echo $item['final_price'] * $item['quantity']; ?></span>
                                    </div>
                                    <div class="text-body-secondary fw-bold"><?php echo $item['color_name']; ?> <?php echo $item['size_name']; ?></div>
                                </div>
                            </li>
                        <?php endforeach; ?>
                        <?php if (count($cartItems) > 0) : ?>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>Total</span>
                                <strong>Rs. <?= $totalSum; ?></strong>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
                <div class="col-md-7 col-lg-8">
                    <h4 class="mb-3">Billing address</h4>
                    <form class="needs-validation" action="components/place-order.php" method="post" novalidate>
                        <div class="row g-3">
                            <input type="hidden" name="userIp" value="<?php echo $userIp; ?>">
                            <input type="hidden" name="cartItems" value="<?php echo htmlspecialchars(json_encode($cartItems)); ?>">
                            <input type="hidden" name="totalPrice" value="<?php echo $totalSum; ?>">
                            <div class="col-12">
                                <label for="fullName" class="form-label">Full Name</label>
                                <input type="text" class="form-control shadow-none" name="fullName" id="fullName" placeholder="" required>
                                <div class="invalid-feedback">
                                    Please enter your name.
                                </div>
                            </div>

                            <div class="col-12">
                                <label for="email" class="form-label">Email <span class="text-body-secondary">(Optional)</span></label>
                                <input type="email" class="form-control shadow-none" name="email" id="email" placeholder="you@example.com">
                                <div class="invalid-feedback">
                                    Please enter a valid email address for shipping updates.
                                </div>
                            </div>

                            <div class="col-12">
                                <label for="number" class="form-label">Phone Number (without dashes)</label>
                                <input type="tel" class="form-control shadow-none" name="phoneNumber" id="number" placeholder="03001234567" required>
                                <div class="invalid-feedback">
                                    Please enter your phone number.
                                </div>
                            </div>

                            <div class="col-12">
                                <label for="address" class="form-label">Address</label>
                                <input type="text" class="form-control shadow-none" name="address" id="address" placeholder="1234 Main St" required>
                                <div class="invalid-feedback">
                                    Please enter your shipping address.
                                </div>
                            </div>

                            <div class="col-md-5">
                                <label for="country" class="form-label">Country</label>
                                <select class="form-select shadow-none" name="country" id="country" required>
                                    <option value="">Choose...</option>
                                    <option value="Pakistan">Pakistan</option>
                                </select>
                                <div class="invalid-feedback">
                                    Please select a valid country.
                                </div>
                            </div>

                            <div class="col-md-4">
                                <label for="province" class="form-label">Province</label>
                                <input type="text" class="form-control shadow-none" name="province" id="province" placeholder="Punjab" required>
                                <div class="invalid-feedback">
                                    Please provide a valid province.
                                </div>
                            </div>

                            <div class="col-md-4">
                                <label for="city" class="form-label">City</label>
                                <input type="text" class="form-control shadow-none" name="city" id="city" placeholder="Faisalabad" required>
                                <div class="invalid-feedback">
                                    Please provide a valid city.
                                </div>
                            </div>

                            <div class="col-md-3">
                                <label for="zip" class="form-label">Zip</label>
                                <input type="text" class="form-control shadow-none" name="zip" id="zip" placeholder="" required>
                                <div class="invalid-feedback">
                                    Zip code required.
                                </div>
                            </div>

                            <div class="col-12">
                                <label for="message" class="form-label">Additional Message <span class="text-body-secondary">(Optional)</span></label>
                                <textarea class="form-control shadow-none" name="message" id="message" rows="5"></textarea>
                                <div class="invalid-feedback">
                                    Please enter a valid message.
                                </div>
                            </div>
                        </div>

                        <hr class="my-4">

                        <h4 class="mb-3">Payment</h4>

                        <div class="my-3">
                            <div class="form-check">
                                <input id="cod" name="paymentMethod" type="radio" class="form-check-input" checked required>
                                <label class="form-check-label" for="cod">Cash on Delivery</label>
                            </div>
                        </div>

                        <hr class="my-4">

                        <button class="w-100 btn btn-primary btn-lg" type="submit">PLACE ORDER</button>
                    </form>
                </div>
            </div>
        </main>
    </div>

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/index.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>

    <script>
        (() => {
            'use strict'

            const forms = document.querySelectorAll('.needs-validation')

            Array.from(forms).forEach(form => {
                form.addEventListener('submit', event => {
                    if (!form.checkValidity()) {
                        event.preventDefault()
                        event.stopPropagation()
                    }

                    form.classList.add('was-validated')
                }, false)
            })
        })()
    </script>
</body>


</html>