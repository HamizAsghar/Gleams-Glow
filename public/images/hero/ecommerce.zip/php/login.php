<?php
require('connection.php');
require('functions.php');
$msg = '';
if (isset($_POST['submit'])) {
    $username = get_safe_value($con, $_POST['username']);
    $password = get_safe_value($con, $_POST['password']);
    $sql = "select * from `admins` where username='$username' and password='$password'";
    $res = mysqli_query($con, $sql);
    $count = mysqli_num_rows($res);
    if ($count > 0) {
        $_SESSION['ADMIN_LOGIN'] = 'yes';
        $_SESSION['ADMIN_USERNAME'] = $username;
        header('location: ./admin');
        die();
    } else {
        $msg = 'Please enter correct username and password';
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="images/favicon.ico" type="image/x-icon" />
    <title>Admin Login | Shopilic</title>

    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
</head>

<body>

    <div class="login_container">
        <div class="login_box">
            <div class="login_heading">ADMIN</div>
            <form method="post">
                <div class="login_input_field row mb-3 mt-4">
                    <label for="username" class="col-sm-2 col-form-label">Username</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="username" name="username" required>
                    </div>
                </div>
                <div class="login_input_field row mb-3">
                    <label for="password" class="col-sm-2 col-form-label">Password</label>
                    <div class="col-sm-10">
                        <input type="password" class="form-control" id="password" name="password" required>
                        <div class="form-check mt-2">
                            <input class="form-check-input" type="checkbox" id="showPassword" onchange="togglePasswordVisibility()">
                            <label class="form-check-label" for="showPassword">
                                Show Password
                            </label>
                        </div>
                    </div>
                </div>
                <div class="login_button mt-4 pt-2 mb-4">
                    <button type="submit" name="submit" class="btn">LOGIN</button>
                </div>
            </form>
            <?php if (!empty($msg)) : ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo $msg; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
                </div>
            <?php endif; ?>
        </div>

    </div>

    <script src="assets/js/index.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script>
        function togglePasswordVisibility() {
            var passwordInput = document.getElementById("password");
            if (passwordInput.type === "password") {
                passwordInput.type = "text";
            } else {
                passwordInput.type = "password";
            }
        }
    </script>


</body>

</html>