<nav class="px-4 py-2">
    <!-- top navbar -->
    <div class="fw-bold d-block d-md-none text-center pb-2 top_nav_text">FREE SHIPPING ON ORDERS ABOVE RS.3000</div>
    <div class="d-flex justify-content-between align-items-center">
        <div class="d-flex gap-2">
            <a href="https://www.facebook.com/profile.php?id=100095042014666" target="_blank"><img src="assets/images/facebook-f.svg" width="18px" height="18px" alt="Facebook" /></a>
            <a href="https://www.instagram.com/shopilicofficial/" target="_blank"><img src="assets/images/square-instagram.svg" width="18px" height="18px" alt="Instagram" /></a>
            <a href="https://twitter.com/ShopIlic" target="_blank"><img src="assets/images/twitter.svg" width="18px" height="18px" alt="Twitter" /></a>
            <a href="https://www.youtube.com/channel/UCEDs2dhy4ZQBprwwG_m0kcw" target="_blank"><img src="assets/images/youtube.svg" width="18px" height="18px" alt="Youtube" /></a>
            <a href="https://www.tiktok.com/@shopilic" target="_blank"><img src="assets/images/tiktok.svg" width="18px" height="18px" alt="Tiktok" /></a>
        </div>
        <div class="fw-bold d-none d-md-block top_nav_text">FREE SHIPPING ON ORDERS ABOVE RS.3000</div>
        <div class="d-flex gap-3">
            <a href="contact.php" class="d-none d-sm-block top_nav_link">Contact Us</a>
            <div class="top_nav_link">0300-1234567</div>
        </div>
    </div>

    <!-- nvabar -->
    <div class="mt-2 d-flex justify-content-between align-items-center gap-3">
        <a href="index.php"><img src="assets/images/logo.png" width="130px" alt="logo" /></a>
        <form class="d-none d-sm-flex justify-content-center align-items-center search_products" action="search.php">
            <input type="search" id="searchproducts" name="keyword" placeholder="Search Products" required>
            <button type="submit" class="d-flex justify-content-center align-items-center"><img src="assets/images/search.svg" width="18px" height="18px" alt="Search" /></button>
        </form>
        <div class="d-flex align-items-center justify-content-center gap-2">
            <button class="navbar-toggler rounded-circle d-flex d-lg-none align-items-center justify-content-center border-0" style="background-color: rgba(0, 0, 0, 0.1); width: 40px; height: 40px" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasExample" aria-controls="offcanvasExample">
                <img src="assets/images/navbar.png" width="20px" height="25px" alt="Search" />
            </button>
            <button type="button" class="rounded-circle d-flex d-sm-none align-items-center justify-content-center border-0" style="background-color: rgba(0, 0, 0, 0.1); width: 40px; height: 40px" data-bs-toggle="modal" data-bs-target="#exampleModal"><img src="assets/images/search.svg" width="20px" height="20px" alt="Search" /></button>
            <a href="cart.php" class="rounded-circle d-flex align-items-center justify-content-center" style="background-color: rgba(0, 0, 0, 0.1); width: 40px; height: 40px"><img src="assets/images/cart-shopping.svg" width="20px" height="20px" alt="Cart" /></a>
        </div>
    </div>

    <!-- search modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Search Products</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form class="d-flex w-100 justify-content-center align-items-center search_products" action="search.php">
                        <input type="search" id="searchproducts" name="keyword" placeholder="Search Products" required>
                        <button type="submit" class="d-flex justify-content-center align-items-center"><img src="assets/images/search.svg" width="18px" height="18px" alt="Search" /></button>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
</nav>

<div class="d-none d-lg-flex bottom_nav">
    <a href="/" class="bottom_nav_link">Home</a>
    <a href="/products.php" class="bottom_nav_link">All Products</a>
    <a href="/featured.php" class="bottom_nav_link">Featured Products</a>
    <a href="/bestselling.php" class="bottom_nav_link">Best Selling Products</a>
    <div class="dropdown">
        <a class="dropdown-toggle bottom_nav_link" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Categories
        </a>

        <ul class="dropdown-menu">
            <?php
            $sql = "SELECT category_name, link FROM categories ORDER BY arrange ASC";
            $result = mysqli_query($con, $sql);

            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo '
                    <li>
                        <a class="dropdown-item" href="category.php?category=' . $row['link'] . '">
                            ' . $row['category_name'] . '
                        </a>
                    </li>';
                }
            } else {
                echo '<li><a class="dropdown-item" href="#">No categories found</a></li>';
            }
            ?>
        </ul>
    </div>
</div>

<div class="offcanvas offcanvas-start" tabindex="-1" id="offcanvasExample" aria-labelledby="offcanvasExampleLabel">
    <div class="offcanvas-header">
        <a href="index.php"><img src="assets/images/logo.png" width="130px" alt="logo" /></a>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body">
        <div class="bottom_nav_offcanvas">
            <a href="/" class="bottom_nav_link_offcanvas">Home</a>
            <a href="/products.php" class="bottom_nav_link_offcanvas">All Products</a>
            <a href="/featured.php" class="bottom_nav_link_offcanvas">Featured Products</a>
            <a href="/bestselling.php" class="bottom_nav_link_offcanvas">Best Selling Products</a>
            <?php
            $sql = "SELECT category_name, link FROM categories ORDER BY arrange ASC";
            $result = mysqli_query($con, $sql);

            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo '
                        <a class="bottom_nav_link_offcanvas" href="category.php?category=' . $row['link'] . '">
                            ' . $row['category_name'] . '
                        </a>';
                }
            } else {
                echo '<div></div>';
            }
            ?>
        </div>
    </div>
</div>