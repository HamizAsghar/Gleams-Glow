<a href="https://wa.me/" target="_blank" class="whatsapp_button">
    <img src="assets/images/whatsapp.png" width="100%" alt="WhatsApp Button" />
</a>