<?php
$sql = "SELECT thumbnail_image, title, slug, price, discounted_price, discounted_percentage FROM products WHERE home_page=1 ORDER BY arrange ASC LIMIT 20";
$result = mysqli_query($con, $sql);

if (mysqli_num_rows($result) > 0) {
    echo '<div class="fs-3 fw-bold text-center px-3 mt-2">Featured Products</div>
        <section class="home_products mt-2 px-4 mb-4">';
    while ($row = mysqli_fetch_assoc($result)) {
        echo '
        <a class="home_products_box text-decoration-none" href="product.php?product=' . $row['slug'] . '">
            <div class="position-relative" style="aspect-ratio: 3/4;background-color: rgba(0, 0, 0, 0.1)">
            <div class="loader-container"><span class="loader"></span></div>
            <img src="assets/uploads/thumbnails/' . basename($row['thumbnail_image']) . '" width="100%" style="object-fit: cover;min-width: 100%;" alt="Product" loading="lazy">
                ';

        if ($row['discounted_percentage'] < 1) {
            echo '';
        } else {
            echo '<div class="position-absolute bg-danger text-white fw-bold" style="top: 10px; left: 10px; font-size: 12px; padding: 3px 10px; border-radius: 5px;">30%</div>';
        }
        echo '<div class="discount_percentage_badge">QUICKVIEW</div>
            </div>
            <div class="text-black mt-2 lh-sm fw-bold">' . $row['title'] . '</div>';

        if ($row['discounted_price'] < 1) {
            echo '<div class="text-black mt-1 lh-sm fw-bold">Rs.' . $row['price'] . '</div>';
        } else {
            echo '<div class="d-flex align-items-center gap-2 mt-1">
                <div class="text-black fw-bold">Rs.' . $row['discounted_price'] . '</div>
                <div class="fw-bold text-decoration-line-through" style="color: gray;">Rs.' . $row['price'] . '</div>
                </div>';
        }

        echo '</a>';
    }
    echo '</section>';
} else {
    echo '<div></div>';
}
if (mysqli_num_rows($result) > 20){
    echo '<div class="mb-4 text-center"><a href="featured.php" class="btn btn-dark rounded-5 py-2 px-4 text-white text-decoration-none">SHOW MORE</a></div>';
}