<?php

require('../connection.php');

$fullName = $_POST['fullName'];
$email = $_POST['email'];
$phoneNumber = $_POST['phoneNumber'];
$address = $_POST['address'];
$country = $_POST['country'];
$province = $_POST['province'];
$city = $_POST['city'];
$zip = $_POST['zip'];
$message = $_POST['message'];
$cartItems = json_decode($_POST['cartItems'], true);
$totalPrice = $_POST['totalPrice'];
$userIp = $_POST['userIp'];

if (empty($fullName) || empty($phoneNumber) || empty($address) || empty($country) || empty($province) || empty($city) || empty($zip)) {
    header("Location: checkout.php?error=Please fill in all required fields");
    exit();
}

$orderDate = date("Y-m-d H:i:s");
$insertOrderQuery = "INSERT INTO orders (full_name, email, phone_number, address, country, province, city, zip, message, order_date, total_amount) 
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
$stmt = mysqli_prepare($con, $insertOrderQuery);
mysqli_stmt_bind_param($stmt, "ssssssssssd", $fullName, $email, $phoneNumber, $address, $country, $province, $city, $zip, $message, $orderDate, $totalPrice);
mysqli_stmt_execute($stmt);

$orderId = mysqli_insert_id($con);

foreach ($cartItems as $item) {
    $productId = $item['product_id'];
    $productTitle = $item['title'];
    $color = $item['color_name'];
    $size = $item['size_name'];
    $quantity = $item['quantity'];
    $pricePerItem = $item['final_price'];
    $subtotal = $quantity * $pricePerItem;

    $insertOrderItemQuery = "INSERT INTO order_items (order_id, product_id, product_title, color, size, quantity, price_per_item, subtotal) 
                             VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($con, $insertOrderItemQuery);
    mysqli_stmt_bind_param($stmt, "iisssidd", $orderId, $productId, $productTitle, $color, $size, $quantity, $pricePerItem, $subtotal);
    mysqli_stmt_execute($stmt);
}

$clearCartQuery = "DELETE FROM cart WHERE ip_address = ?";
$stmt = mysqli_prepare($con, $clearCartQuery);
mysqli_stmt_bind_param($stmt, "s", $userIp);
mysqli_stmt_execute($stmt);

header("Location: ../orderplaced.html");
exit();
