<?php

// Fetch random product from the database
$sql = "SELECT slug, title, thumbnail_image FROM products ORDER BY RAND() LIMIT 1";
$result = mysqli_query($con, $sql);

// Check if query was successful and at least one product was found
if ($result && mysqli_num_rows($result) > 0) {
    $product = mysqli_fetch_assoc($result);
    $productSlug = $product['slug'];
    $productName = $product['title'];
    $productImage = $product['thumbnail_image'];
} else {
    // Default product data if no product found (you can adjust this as needed)
    $productSlug = "";
    $productName = "";
    $productImage = "";
}
?>

<a id="popup" href="<?php echo 'product.php?product=' . $productSlug; ?>" class="text-decoration-none z-3 fake_popup position-fixed">
    <div class="d-flex align-items-center">
        <div class="fake_popup_image">
            <img src="assets/uploads/thumbnails/<?php echo $productImage; ?>" width="100%" id="productImage" alt="Product Image">
        </div>
        <div class="p-2">
            <div style="color: gray; font-weight: bold;" class="fake_popup_text">Someone purchased:</div>
            <div style="font-weight: bold; color: black;" class="mt-1 fake_popup_text"><?php echo $productName; ?></div>
        </div>
    </div>
</a>

<script>
    // Function to show the popup with product information
    function showPopup() {
        document.getElementById("popup").style.display = "block";
        setTimeout(hidePopup, 5000); // Hide popup after 5 seconds
    }

    // Function to hide the popup
    function hidePopup() {
        document.getElementById("popup").style.display = "none";
        setTimeout(showPopup, 15000); // Show popup again after 15 seconds
    }

    // Start showing the popup
    showPopup();
</script>