<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $itemId = $_POST['itemId'];

    require('../connection.php');

    $query = "DELETE FROM cart WHERE id = ?";
    $statement = mysqli_prepare($con, $query);
    mysqli_stmt_bind_param($statement, "i", $itemId);
    $success = mysqli_stmt_execute($statement);

    if ($success) {
        header("Location: ../cart.php");
        exit();
    } else {
        echo "Error removing item from cart.";
    }

    mysqli_stmt_close($statement);
    mysqli_close($con);
} else {
    http_response_code(405); // Method Not Allowed
    echo json_encode(['message' => 'Method not allowed']);
}
