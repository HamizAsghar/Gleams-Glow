<footer class="py-5 px-2" style="border-top: 1px solid silver; background-color: #fafafa;">
    <div class="container d-flex justify-content-evenly gap-4">
        <div>
            <h5 class="fw-bold">QUICK LINKS</h5>
            <div class="d-flex flex-column gap-2 mt-4">
                <a href="index.php" class="text-black text-decoration-none" style="font-weight: 500;">Home</a>
                <a href="products.php" class="text-black text-decoration-none" style="font-weight: 500;">All Products</a>
                <a href="featured.php" class="text-black text-decoration-none" style="font-weight: 500;">Featured Products</a>
                <a href="bestselling.php" class="text-black text-decoration-none" style="font-weight: 500;">Best Selling Products</a>
                <a href="cart.php" class="text-black text-decoration-none" style="font-weight: 500;">Cart</a>
            </div>
        </div>
        <div>
            <h5 class="fw-bold">CUSTOMER CARE</h5>
            <div class="d-flex flex-column gap-2 mt-4">
                <a href="contact.php" class="text-black text-decoration-none" style="font-weight: 500;">Contact Us</a>
                <a href="contact.php" class="text-black text-decoration-none" style="font-weight: 500;">Ask a Question</a>
                <a href="" class="text-black text-decoration-none" style="font-weight: 500;">+92 317 1116221</a>
            </div>
        </div>
    </div>
    <div class="d-flex gap-2 gap-md-3 mt-4 justify-content-center">
        <a href="https://www.facebook.com/profile.php?id=100095042014666" target="_blank"><img src="assets/images/facebook.png" width="25px" height="25px" alt="Facebook" /></a>
        <a href="https://www.instagram.com/shopilicofficial/" target="_blank"><img src="assets/images/instagram.png" width="25px" height="25px" alt="Instagram" /></a>
        <a href="https://twitter.com/ShopIlic" target="_blank"><img src="assets/images/twitter.png" width="25px" height="25px" alt="Twitter" /></a>
        <a href="https://www.youtube.com/channel/UCEDs2dhy4ZQBprwwG_m0kcw" target="_blank"><img src="assets/images/youtube.png" width="25px" height="25px" alt="Youtube" /></a>
        <a href="https://www.tiktok.com/@shopilic" target="_blank"><img src="assets/images/tiktok.png" width="25px" height="25px" alt="Tiktok" /></a>
    </div>
    <div class="mt-4 text-center">&copy; 2021 - <?php echo date('Y'); ?>, Shopilic</div>
</footer>