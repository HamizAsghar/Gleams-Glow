<?php
$sql = "SELECT * FROM categories ORDER BY arrange ASC";
$result = mysqli_query($con, $sql);

if (mysqli_num_rows($result) > 0) {
    echo '<div class="fs-3 fw-bold text-center px-3 mt-2">Shop by Category</div>
        <section class="home_categories mt-2 px-4">';
    while ($row = mysqli_fetch_assoc($result)) {
        echo '<div class="home_categories_box">
                <a class="home_banner_large" href="category.php?category=' . $row['link'] . '">
                    <img src="assets/uploads/' . basename($row['desktop_image_path']) . '" width="100%" style="object-fit: cover;min-width: 100%;" alt="Category" loading="lazy">
                </a>
                <a class="home_banner_small" href="category.php?category=' . $row['link'] . '">
                    <img src="assets/uploads/' . basename($row['mobile_image_path']) . '" width="100%" style="object-fit: cover;min-width: 100%;" alt="Category" loading="lazy">
                </a>
                <div>' . $row['category_name'] . '</div>
            </div>';
    }
    echo '</section>';
} else {
    echo '<div></div>';
}
