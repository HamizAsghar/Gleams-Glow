<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $productId = $_POST['itemId'];
    $newQuantity = filter_input(INPUT_POST, 'quantity', FILTER_VALIDATE_INT);
    $newQuantity = (int) $newQuantity;

    if ($newQuantity === false || $newQuantity < 1 || $newQuantity > 20) {
        http_response_code(400);
        echo json_encode(['message' => 'Invalid quantity. Please enter a number between 1 and 20.']);
        exit();
    }

    require('../connection.php');

    $query = "UPDATE cart SET quantity = ? WHERE id = ?";
    $statement = mysqli_prepare($con, $query);

    mysqli_stmt_bind_param($statement, "ii", $newQuantity, $productId);

    $success = mysqli_stmt_execute($statement);

    if ($success) {
        header("Location: ../cart.php");
        exit();
    } else {
        echo "Error updating quantity: " . mysqli_error($con);
    }

    mysqli_stmt_close($statement);

    mysqli_close($con);
} else {
    http_response_code(405);
    echo json_encode(['message' => 'Method not allowed']);
}
