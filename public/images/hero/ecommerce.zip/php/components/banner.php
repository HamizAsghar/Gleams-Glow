<section class="owl-carousel d-flex align-items-center justify-content-center fw-bold fs-1 home_banner_box">
    <?php
    $sql = "SELECT * FROM banners ORDER BY arrange ASC";
    $result = mysqli_query($con, $sql);

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            // Construct the srcset attribute for responsive images
            $srcsetDesktop = 'assets/uploads/' . basename($row['desktop_image_path']) . ' 1200w';
            $srcsetMobile = 'assets/uploads/' . basename($row['mobile_image_path']) . ' 768w';

            echo '<div class="item home_banner">
                <a href="' . $row['link'] . '">
                    <img src="assets/uploads/' . basename($row['desktop_image_path']) . '" srcset="' . $srcsetMobile . ', ' . $srcsetDesktop . '" alt="Banner" loading="lazy">
                </a>
            </div>';
        }
    } else {
        echo '<div></div>';
    }
    ?>
</section>