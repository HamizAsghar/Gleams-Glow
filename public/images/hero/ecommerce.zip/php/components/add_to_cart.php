<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the data sent via the POST request
    $productId = $_POST['productId'];
    $quantity = $_POST['quantity'];
    $colorId = $_POST['color_id'] ?? null;
    $sizeId = $_POST['size_id'] ?? null;
    $colorName = $_POST['color_name'] ?? '';
    $sizeName = $_POST['size_name'] ?? '';

    // Fetching user IP address
    function getUserIP()
    {
        $IP = false;
        if (getenv('HTTP_CLIENT_IP')) {
            $IP = getenv('HTTP_CLIENT_IP');
        } else if (getenv('HTTP_X_FORWARDED_FOR')) {
            $IP = getenv('HTTP_X_FORWARDED_FOR');
        } else if (getenv('HTTP_X_FORWARDED')) {
            $IP = getenv('HTTP_X_FORWARDED');
        } else if (getenv('HTTP_FORWARDED_FOR')) {
            $IP = getenv('HTTP_FORWARDED_FOR');
        } else if (getenv('HTTP_FORWARDED')) {
            $IP = getenv('HTTP_FORWARDED');
        } else if (getenv('REMOTE_ADDR')) {
            $IP = getenv('REMOTE_ADDR');
        }

        //If HTTP_X_FORWARDED_FOR == server ip
        if ((($IP) && ($IP == getenv('SERVER_ADDR')) && (getenv('REMOTE_ADDR')) || (!filter_var($IP, FILTER_VALIDATE_IP)))) {
            $IP = getenv('REMOTE_ADDR');
        }

        if ($IP) {
            if (!filter_var($IP, FILTER_VALIDATE_IP)) {
                $IP = false;
            }
        } else {
            $IP = false;
        }
        return $IP;
    }

    $userIp = str_replace(['.', ':'], ['', ''], getUserIP());

    // Establish database connection
    require('../connection.php');

    // Insert the product into the cart table
    $insertQuery = "INSERT INTO cart (product_id, quantity, color_id, size_id, color_name, size_name, ip_address) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $insertStmt = mysqli_prepare($con, $insertQuery);
    mysqli_stmt_bind_param($insertStmt, "iiissss", $productId, $quantity, $colorId, $sizeId, $colorName, $sizeName, $userIp);
    mysqli_stmt_execute($insertStmt);

    // Check if the insertion was successful
    if (mysqli_stmt_affected_rows($insertStmt) > 0) {
        // Redirect back to the product page using the slug
        $productSlug = getProductSlug($con, $productId);
        if ($productSlug) {
            header("Location: ../product.php?product={$productSlug}");
            exit();
        }
    } else {
        // If insertion failed, return an error message
        $response = array("success" => false, "message" => "Failed to add product to cart");
        echo json_encode($response);
    }

    // Close the database connection
    mysqli_stmt_close($insertStmt);
    mysqli_close($con);
} else {
    // Return an error message if the request method is not POST
    $response = array("success" => false, "message" => "Invalid request method");
    echo json_encode($response);
}

// Function to get product slug from product ID
function getProductSlug($con, $productId)
{
    $query = "SELECT slug FROM products WHERE id = ?";
    $stmt = mysqli_prepare($con, $query);
    mysqli_stmt_bind_param($stmt, "i", $productId);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $product = mysqli_fetch_assoc($result);
    mysqli_stmt_close($stmt);
    return $product ? $product['slug'] : null;
}
