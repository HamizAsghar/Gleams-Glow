<?php
require('connection.php');

function getUserIP()
{
    $IP = false;
    if (getenv('HTTP_CLIENT_IP')) {
        $IP = getenv('HTTP_CLIENT_IP');
    } else if (getenv('HTTP_X_FORWARDED_FOR')) {
        $IP = getenv('HTTP_X_FORWARDED_FOR');
    } else if (getenv('HTTP_X_FORWARDED')) {
        $IP = getenv('HTTP_X_FORWARDED');
    } else if (getenv('HTTP_FORWARDED_FOR')) {
        $IP = getenv('HTTP_FORWARDED_FOR');
    } else if (getenv('HTTP_FORWARDED')) {
        $IP = getenv('HTTP_FORWARDED');
    } else if (getenv('REMOTE_ADDR')) {
        $IP = getenv('REMOTE_ADDR');
    }

    //If HTTP_X_FORWARDED_FOR == server ip
    if ((($IP) && ($IP == getenv('SERVER_ADDR')) && (getenv('REMOTE_ADDR')) || (!filter_var($IP, FILTER_VALIDATE_IP)))) {
        $IP = getenv('REMOTE_ADDR');
    }

    if ($IP) {
        if (!filter_var($IP, FILTER_VALIDATE_IP)) {
            $IP = false;
        }
    } else {
        $IP = false;
    }
    return $IP;
}

$userIp = str_replace(['.', ':'], ['', ''], getUserIP());

$query = "SELECT c.*, 
p.title, 
p.thumbnail_image, 
p.slug, 
IF(p.discounted_price = 0, p.price, p.discounted_price) AS final_price,
COALESCE(color_name, '') AS color_name,
COALESCE(size_name, '') AS size_name
FROM cart c
INNER JOIN products p ON c.product_id = p.id 
LEFT JOIN variants AS color ON c.color_id = color.id AND color.type = 'color'
LEFT JOIN variants AS size ON c.size_id = size.id AND size.type = 'size'
WHERE c.ip_address = ?
ORDER BY c.id DESC";

$stmt = mysqli_prepare($con, $query);
mysqli_stmt_bind_param($stmt, "s", $userIp);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if ($result) {
    $cartItems = mysqli_fetch_all($result, MYSQLI_ASSOC);

    $totalSum = 0;
    foreach ($cartItems as $item) {
        $totalSum += $item['final_price'] * $item['quantity'];
    }
} else {
    $cartItems = [];
    $totalSum = 0;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-159HFH84B1"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'G-159HFH84B1');
    </script>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="images/favicon.ico" type="image/x-icon" />
    <title>Cart - Shopilic</title>

    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">

</head>

<body class="position-relative">

    <?php include('components/header.php'); ?>

    <main class="px-5">

        <div class="col-12 mt-5">
            <div class="cart-table">
                <div class="table-responsive">
                    <table class="table table-bordered mb-30 overflow-y-auto">
                        <thead>
                            <tr>
                                <th scope="col"></th>
                                <th scope="col">Image</th>
                                <th scope="col">Product</th>
                                <th scope="col">Color</th>
                                <th scope="col">Size</th>
                                <th class="text-nowrap" scope="col">Unit Price</th>
                                <th scope="col">Quantity</th>
                                <th scope="col">Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($cartItems as $item) : ?>
                                <tr>
                                    <th class="text-nowrap" scope="row" style="text-align: center;">
                                        <form action="components/remove_item_from_cart.php" method="POST">
                                            <input type="hidden" name="itemId" value="<?= $item['id']; ?>">
                                            <button type="submit" class="remove-item-btn" style="background: none; border: none; padding: 0; cursor: pointer;">
                                                <img width="20px" src="assets/images/remove.png" alt="Remove Icon" />
                                            </button>
                                        </form>
                                    </th>
                                    <td>
                                        <img width="60px" height="60px" class="object-fit-cover rounded-circle" src="assets/uploads/thumbnails/<?= $item['thumbnail_image']; ?>" alt="<?= $item['title']; ?>">
                                    </td>
                                    <td style="min-width: 250px;">
                                        <a href="product.php?product=<?= $item['slug']; ?>" class="text-dark text-decoration-none"><?= $item['title']; ?></a>
                                    </td>
                                    <td class="text-nowrap"><?= $item['color_name']; ?></td>
                                    <td class="text-nowrap"><?= $item['size_name']; ?></td>
                                    <td class="text-nowrap">Rs. <?= $item['final_price']; ?></td>
                                    <td>
                                        <form action="components/update_cart_quantity.php" method="POST">
                                            <div class="d-flex align-items-center">
                                                <button type="submit" style="width: 33px; height: 30px; display: flex; align-items: center; justify-content: center; font-size: 18px; font-weight: bold;" class="btn px-2 py-0 rounded-0 btn-outline-danger decrement-btn">-</button>
                                                <input type="number" class="qty-text text-center" style="height: 30px; outline: none; border: 1px solid gray;" id="qty<?= $item['id']; ?>" step="1" min="1" max="10" name="quantity" value="<?= $item['quantity']; ?>">
                                                <button type="submit" style="width: 33px; height: 30px; display: flex; align-items: center; justify-content: center; font-size: 18px; font-weight: bold;" class="btn px-2 py-0 rounded-0 btn-outline-success increment-btn">+</button>
                                            </div>
                                            <input type="hidden" name="itemId" value="<?= $item['id']; ?>">
                                        </form>
                                    </td>
                                    <td class="text-nowrap">Rs. <?= $item['final_price'] * $item['quantity']; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="col-12 col-lg-5 mx-auto my-5">
            <div class="cart-total-area mb-30">
                <h5 class="mb-3">Cart Total</h5>
                <div class="table-responsive">
                    <table class="table mb-3">
                        <tbody>
                            <tr>
                                <td>Total</td>
                                <td id="cart-total">Rs. <?= $totalSum; ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <?php if (count($cartItems) > 0) : ?>
                    <a href="checkout.php" class="btn btn-dark d-block">Proceed To Checkout</a>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <?php include('components/footer.php'); ?>
    <?php include('components/whatsapp.php'); ?>
    <?php include('components/popup.php'); ?>

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const decrementBtns = document.querySelectorAll('.decrement-btn');
            const incrementBtns = document.querySelectorAll('.increment-btn');

            decrementBtns.forEach(btn => {
                btn.addEventListener('click', function() {
                    const input = btn.nextElementSibling;
                    const newValue = parseInt(input.value) - 1;
                    if (newValue >= parseInt(input.min)) {
                        input.value = newValue;
                    }
                });
            });

            incrementBtns.forEach(btn => {
                btn.addEventListener('click', function() {
                    const input = btn.previousElementSibling;
                    const newValue = parseInt(input.value) + 1;
                    if (newValue <= parseInt(input.max)) {
                        input.value = newValue;
                    }
                });
            });

        });
    </script>

</body>

</html>