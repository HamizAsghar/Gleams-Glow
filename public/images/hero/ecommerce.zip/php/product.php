<?php
function Get_User_Ip()
{
    $IP = false;
    if (getenv('HTTP_CLIENT_IP')) {
        $IP = getenv('HTTP_CLIENT_IP');
    } else if (getenv('HTTP_X_FORWARDED_FOR')) {
        $IP = getenv('HTTP_X_FORWARDED_FOR');
    } else if (getenv('HTTP_X_FORWARDED')) {
        $IP = getenv('HTTP_X_FORWARDED');
    } else if (getenv('HTTP_FORWARDED_FOR')) {
        $IP = getenv('HTTP_FORWARDED_FOR');
    } else if (getenv('HTTP_FORWARDED')) {
        $IP = getenv('HTTP_FORWARDED');
    } else if (getenv('REMOTE_ADDR')) {
        $IP = getenv('REMOTE_ADDR');
    }

    //If HTTP_X_FORWARDED_FOR == server ip
    if ((($IP) && ($IP == getenv('SERVER_ADDR')) && (getenv('REMOTE_ADDR')) || (!filter_var($IP, FILTER_VALIDATE_IP)))) {
        $IP = getenv('REMOTE_ADDR');
    }

    if ($IP) {
        if (!filter_var($IP, FILTER_VALIDATE_IP)) {
            $IP = false;
        }
    } else {
        $IP = false;
    }
    return $IP;
}

$user_ip = Get_User_Ip();
?>

<?php
require('connection.php');

if (isset($_GET['product'])) {
    $slug = $_GET['product'];
    $sql = "SELECT * FROM products WHERE slug = ?";
    $stmt = mysqli_prepare($con, $sql);
    mysqli_stmt_bind_param($stmt, "s", $slug);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if (mysqli_num_rows($result) == 1) {
        $product = mysqli_fetch_assoc($result);

        // Fetch product images
        $fetch_images = "SELECT * FROM product_images WHERE product_id = ?";
        $stmt_images = mysqli_prepare($con, $fetch_images);
        mysqli_stmt_bind_param($stmt_images, "i", $product['id']);
        mysqli_stmt_execute($stmt_images);
        $result_images = mysqli_stmt_get_result($stmt_images);

        // Fetched images are stored in an array
        $images = [];
        while ($row = mysqli_fetch_assoc($result_images)) {
            $images[] = $row['image_path']; // Assuming 'image_path' is the column containing the image paths or URLs
        }

        // Update views and date_view columns
        $currentDate = date("Y-m-d");
        $select_sql = "SELECT date_view FROM products WHERE id = ?";
        $stmt_select = mysqli_prepare($con, $select_sql);
        mysqli_stmt_bind_param($stmt_select, "i", $product['id']);
        mysqli_stmt_execute($stmt_select);
        $result = mysqli_stmt_get_result($stmt_select);
        $row = mysqli_fetch_assoc($result);

        if ($row) {
            $dateView = $row['date_view'];
            if ($dateView == $currentDate) {
                // If date_view matches current date, increment views
                $update_sql = "UPDATE products SET views = views + 1 WHERE id = ?";
                $stmt_update = mysqli_prepare($con, $update_sql);
                mysqli_stmt_bind_param($stmt_update, "i", $product['id']);
                mysqli_stmt_execute($stmt_update);
            } else {
                // If date_view does not match current date, reset views to 1 and update date_view
                $update_sql = "UPDATE products SET views = 1, date_view = ? WHERE id = ?";
                $stmt_update = mysqli_prepare($con, $update_sql);
                mysqli_stmt_bind_param($stmt_update, "si", $currentDate, $product['id']);
                mysqli_stmt_execute($stmt_update);
            }
        }

        $variants = [];
        $fetch_variants_sql = "SELECT v.name, v.type FROM product_variants pv JOIN variants v ON pv.variant_id = v.id WHERE pv.product_id = ?";
        $stmt_variants = mysqli_prepare($con, $fetch_variants_sql);
        mysqli_stmt_bind_param($stmt_variants, "i", $product['id']);
        mysqli_stmt_execute($stmt_variants);
        $result_variants = mysqli_stmt_get_result($stmt_variants);

        while ($row = mysqli_fetch_assoc($result_variants)) {
            $variants[$row['type']][] = $row['name'];
        }
    } else {
        header('Location: 404.php');
        exit();
    }
} else {
    header('Location: 404.php');
    exit();
}

$product_types = [
    1 => "DYED W/O EMBROIDERED",
    2 => "DYED+EMBROIDERED",
    3 => "PASTED+EMBROIDERED",
    4 => "PASTED+PRINTED",
    5 => "PRINTED W/O EMBROIDERED",
    6 => "PRINTED+EMBROIDERED",
]
?>

<?php

$discount_timer = 8 * 60 * 60;
if (!isset($_SESSION['discount_start_time']) || time() - $_SESSION['discount_start_time'] >= $discount_timer) {
    $_SESSION['discount_start_time'] = time();
}
$remaining_time = $discount_timer - (time() - $_SESSION['discount_start_time']);

?>

<?php

// Get the product details
if (isset($_GET['product'])) {
    $slug = $_GET['product'];
    $sql = "SELECT * FROM products WHERE slug = ?";
    $stmt = mysqli_prepare($con, $sql);
    mysqli_stmt_bind_param($stmt, "s", $slug);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if (mysqli_num_rows($result) == 1) {
        $product = mysqli_fetch_assoc($result);

        // Fetch variants for the product
        $fetch_variants_sql = "SELECT v.name, v.type FROM product_variants pv JOIN variants v ON pv.variant_id = v.id WHERE pv.product_id = ?";
        $stmt_variants = mysqli_prepare($con, $fetch_variants_sql);
        mysqli_stmt_bind_param($stmt_variants, "i", $product['id']);
        mysqli_stmt_execute($stmt_variants);
        $result_variants = mysqli_stmt_get_result($stmt_variants);

        // Store variants in an array
        $variants = [];
        while ($row = mysqli_fetch_assoc($result_variants)) {
            $variants[$row['type']][] = $row['name'];
        }
    } else {
        header('Location: 404.php');
        exit();
    }
} else {
    header('Location: 404.php');
    exit();
}

?>



<!DOCTYPE html>
<html lang="en">

<head>

    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-159HFH84B1"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'G-159HFH84B1');
    </script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="images/favicon.ico" type="image/x-icon" />
    <title>Shopilic | <?php echo $product['title']; ?></title>

    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="magnify/magnify.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">

</head>

<body class="position-relative">

    <?php include('components/header.php'); ?>

    <main class="d-flex flex-column flex-lg-row gap-3 px-4 mt-2 mb-4">
        <section class="flex-grow-1 w-100 order-2 order-lg-1">
            <?php
            if (isset($images) && is_array($images) && count($images) > 0) {
                echo '<div class="d-flex align-items-center flex-wrap gap-2">';
                for ($i = 0; $i < count($images); $i++) {
                    echo '<div><img src="assets/uploads/product_images/' . $images[$i] . '" data-magnify-src="assets/uploads/product_images/' . $images[$i] . '" width="100px" width="100px" height="100%" alt="' . $product['title'] . '" style="cursor: pointer;" class="thumbnail" data-index="' . $i . '"  /></div>';
                }
                echo '</div>';
            }
            ?>
            <?php
            echo '
                <div class="mt-4 d-none d-lg-block">
                    <h5>Description:</h5>
                    <p>' . $product['description'] . '</p>
                </div>
            ';
            ?>
        </section>

        <section class="flex-grow-1 w-100 order-1 order-lg-2">
            <!-- Product large image -->
            <?php
            if (isset($images) && is_array($images) && count($images) > 0) {
                echo '<div><img id="largeImage" src="assets/uploads/product_images/' . $images[0] . '" data-magnify-src="assets/uploads/product_images/' . $images[0] . '" width="100%" height="100%" alt="' . $product['title'] . '" class="zoom" /></div>';
            } else {
                echo '<div>No image available</div>';
            }
            ?>
        </section>

        <section class="flex-grow-1 w-100 order-3">
            <?php
            echo '
                <h3>' . $product['title'] . '</h3>
            ';
            ?>
            <?php
            if ($product['discounted_price'] < 1) {
                echo '<h4 class="text-black mt-3 lh-sm">Rs.' . $product['price'] . '</h4>';
            } else {
                echo '<div class="d-flex align-items-center gap-3 mt-3">
                    <h4 class="text-black">Rs.' . $product['discounted_price'] . '</h4>
                    <h5 class="text-decoration-line-through" style="color: gray;">Rs.' . $product['price'] . '</h5>
                    </div>';
            }
            if ($product['type'] == '0') {
                echo '';
            } else {
                echo '<div class="d-flex align-items-center gap-3 mt-3">
                    <h5 class="fw-normal">Type: </h5>
                    <h5 class="">' . $product_types[$product['type']] . '</h5>
                    </div>';
            }
            if ($product['pieces'] == '0') {
                echo '';
            } else {
                echo '<div class="d-flex align-items-center gap-3">
                    <h5 class="fw-normal">Pieces: </h5>
                    <h5 class="">' . $product['pieces'] . ' Piece</h5>
                    </div>';
            }
            ?>
            <?php
            echo '
                <div class="mt-3 d-block d-lg-none">
                    <h5>Description:</h5>
                    <p>' . $product['description'] . '</p>
                </div>
            ';
            ?>

            <form id="product-form" action="components/add_to_cart.php" method="POST">
                <input type="hidden" name="productId" value="<?php echo $product['id']; ?>">
                <!-- Hidden input fields for color and size names -->
                <input type="hidden" id="color-name" name="color_name" value="">
                <input type="hidden" id="size-name" name="size_name" value="">
                <div class="mt-3 d-flex flex-wrap gap-3 align-items-center">
                    <?php if (!empty($variants['color'])) : ?>
                        <select id="color-select" class="form-select variant-select" name="color_id" required>
                            <option value="" selected disabled>Select Color</option>
                            <?php foreach ($variants['color'] as $color) : ?>
                                <option value="<?php echo $color; ?>"><?php echo $color; ?></option>
                            <?php endforeach; ?>
                        </select>
                    <?php endif; ?>
                    <?php if (!empty($variants['size'])) : ?>
                        <select id="size-select" class="form-select variant-select" name="size_id" required>
                            <option value="" selected disabled>Select Size</option>
                            <?php foreach ($variants['size'] as $size) : ?>
                                <option value="<?php echo $size; ?>"><?php echo $size; ?></option>
                            <?php endforeach; ?>
                        </select>
                    <?php endif; ?>
                    <button class="add-to-cart-btn btn btn-outline-dark">Add to Cart</button>
                </div>
                <div style="max-width: fit-content;" class="ps-4 ms-2">
                    <div class="qty-input mt-4">
                        <button class="qty-count qty-count--minus" data-action="minus" type="button">-</button>
                        <input class="product-qty" type="number" name="quantity" min="1" max="10" value="1" required>
                        <button class="qty-count qty-count--add" data-action="add" type="button">+</button>
                    </div>
                </div>
            </form>


            <?php
            if ($product['discounted_percentage'] == '0') {
                echo '';
            } else {
                echo '<div id="discount-timer" class="mt-4 pt-3 product_discount_timer_box">
                <div class="product_discount_timer_heading">🔥 Hurry Up 🔥</div>
                <div class="product_discount_timer_text">sale ends in</div>
                <p id="timer" class="product_discount_timer"></p>
            </div>';
            }
            ?>

        </section>
    </main>

    <!-- Best Selling Carousel -->
    <?php include('components/best-selling-carousel.php'); ?>

    <?php include('components/footer.php'); ?>
    <?php include('components/whatsapp.php'); ?>
    <?php include('components/popup.php'); ?>

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="magnify/jquery.magnify.js"></script>
    <script src="magnify/jquery.magnify-mobile.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script>
        $(function() {
            var $zoom = $('.zoom').magnify();
        });

        // Show Large Image
        document.addEventListener('DOMContentLoaded', function() {
            const thumbnails = document.querySelectorAll('.thumbnail');
            const largeImage = document.getElementById('largeImage');

            thumbnails.forEach(function(thumbnail) {
                thumbnail.addEventListener('click', function() {
                    const imageUrl = thumbnail.getAttribute('src');
                    const imageZoomUrl = thumbnail.dataset.magnifySrc;

                    largeImage.src = imageUrl;
                    largeImage.dataset.magnifySrc = imageZoomUrl;

                    $('.zoom').magnify('destroy');
                    $('.zoom').magnify();
                });
            });
        });


        // Owl Carousel
        jQuery(document).ready(function($) {
            $(".owl-carousel").owlCarousel({
                margin: 10,
                nav: true,
                responsive: {
                    0: {
                        items: 1,
                    },
                    768: {
                        items: 3,
                    },
                    992: {
                        items: 4,
                    },
                    1200: {
                        items: 5,
                    },
                    1536: {
                        items: 6,
                    }
                },
            });
        });

        // Quantity Button
        var QtyInput = (function() {
            var $qtyInputs = $(".qty-input");
            if (!$qtyInputs.length) {
                return;
            }
            var $inputs = $qtyInputs.find(".product-qty");
            var $countBtn = $qtyInputs.find(".qty-count");
            var qtyMin = parseInt($inputs.attr("min"));
            var qtyMax = parseInt($inputs.attr("max"));
            $inputs.change(function() {
                var $this = $(this);
                var $minusBtn = $this.siblings(".qty-count--minus");
                var $addBtn = $this.siblings(".qty-count--add");
                var qty = parseInt($this.val());

                if (isNaN(qty) || qty <= qtyMin) {
                    $this.val(qtyMin);
                    $minusBtn.attr("disabled", true);
                } else {
                    $minusBtn.attr("disabled", false);

                    if (qty >= qtyMax) {
                        $this.val(qtyMax);
                        $addBtn.attr('disabled', true);
                    } else {
                        $this.val(qty);
                        $addBtn.attr('disabled', false);
                    }
                }
            });
            $countBtn.click(function() {
                var operator = this.dataset.action;
                var $this = $(this);
                var $input = $this.siblings(".product-qty");
                var qty = parseInt($input.val());

                if (operator == "add") {
                    qty += 1;
                    if (qty >= qtyMin + 1) {
                        $this.siblings(".qty-count--minus").attr("disabled", false);
                    }

                    if (qty >= qtyMax) {
                        $this.attr("disabled", true);
                    }
                } else {
                    qty = qty <= qtyMin ? qtyMin : (qty -= 1);

                    if (qty == qtyMin) {
                        $this.attr("disabled", true);
                    }

                    if (qty < qtyMax) {
                        $this.siblings(".qty-count--add").attr("disabled", false);
                    }
                }

                $input.val(qty);
            });
        })();

        $(document).ready(function() {
            $('#color-select').change(function() {
                var colorName = $(this).val();
                $('#color-name').val(colorName);
            });

            $('#size-select').change(function() {
                var sizeName = $(this).val();
                $('#size-name').val(sizeName);
            });
        });

        function updateTimer() {
            var remainingTime = <?php echo $remaining_time; ?>;
            var timerElement = document.getElementById("timer");

            function formatTime(time) {
                return time < 10 ? "0" + time : time;
            }

            function displayTimer() {
                var hours = Math.floor(remainingTime / 3600);
                var minutes = Math.floor((remainingTime % 3600) / 60);
                var seconds = remainingTime % 60;
                timerElement.innerHTML = formatTime(hours) + "h " + formatTime(minutes) + "m " + formatTime(seconds) + "s";
                remainingTime--;
                if (remainingTime >= 0) {
                    setTimeout(displayTimer, 1000);
                }
            }
            displayTimer();
        }
        updateTimer();
    </script>

</body>

</html>