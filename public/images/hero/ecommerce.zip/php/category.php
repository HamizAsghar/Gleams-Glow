<?php
require('connection.php');

if (isset($_GET['category'])) {
    $link = $_GET['category'];
    $sql = "SELECT id, category_name, link FROM categories WHERE link = ?";
    $stmt = mysqli_prepare($con, $sql);
    mysqli_stmt_bind_param($stmt, "s", $link);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if (mysqli_num_rows($result) == 1) {
        $category = mysqli_fetch_assoc($result);

        $chk_products_with_category = "SELECT product_id FROM product_categories WHERE category_id = ?";
        $stmt1 = mysqli_prepare($con, $chk_products_with_category);
        mysqli_stmt_bind_param($stmt1, "s", $category['id']);
        mysqli_stmt_execute($stmt1);
        $product_ids_result = mysqli_stmt_get_result($stmt1);

        if (mysqli_num_rows($product_ids_result) > 0) {
            $products = array();

            while ($row = mysqli_fetch_assoc($product_ids_result)) {
                $product_id = $row['product_id'];
                $fetch_product_details = "SELECT thumbnail_image, title, slug, pieces, type, price, discounted_price, discounted_percentage FROM products WHERE id = ?";
                $stmt2 = mysqli_prepare($con, $fetch_product_details);
                mysqli_stmt_bind_param($stmt2, "s", $product_id);
                mysqli_stmt_execute($stmt2);
                $product_details_result = mysqli_stmt_get_result($stmt2);

                if (mysqli_num_rows($product_details_result) == 1) {
                    $product_details = mysqli_fetch_assoc($product_details_result);
                    $products[] = $product_details;
                }
            }
        } else {
            header('Location: 404.php');
            exit();
        }
    } else {
        header('Location: 404.php');
        exit();
    }
} else {
    header('Location: 404.php');
    exit();
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-159HFH84B1"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'G-159HFH84B1');
    </script>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="images/favicon.ico" type="image/x-icon" />
    <title>Shopilic | <?php echo $category['category_name']; ?></title>

    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">

</head>

<body class="position-relative">

    <?php include('components/header.php'); ?>

    <nav style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='%236c757d'/%3E%3C/svg%3E&#34;);" aria-label="breadcrumb" class="px-4 mt-4 mb-2">
        <ol class="breadcrumb">
            <li class="breadcrumb-item fw-bold"><a href="index.php" class="text-decoration-none text-black">HOME</a></li>
            <li class="breadcrumb-item fw-bold active" aria-current="page"><?php echo '' . $category['category_name'] . ''; ?></li>
        </ol>
    </nav>

    <div class="fs-3 fw-bold text-center px-3 mt-2 mb-4"><?php echo '' . $category['category_name'] . ''; ?></div>

    <main class="d-flex flex-column flex-lg-row gap-4">
        <section class="flex-grow-1">
            <?php
            $results_per_page = 20;
            $total_results = count($products);
            $total_pages = ceil($total_results / $results_per_page);
            $current_page = isset($_GET['page']) ? $_GET['page'] : 1;
            $offset = ($current_page - 1) * $results_per_page;

            if (!empty($products)) {
                echo '<section class="home_products mt-2 px-4 mb-4">';
                for ($i = $offset; $i < min($offset + $results_per_page, $total_results); $i++) {
                    $product = $products[$i];
                    echo '
                    <a class="home_products_box text-decoration-none" href="product.php?product=' . $product['slug'] . '">
                        <div class="position-relative" style="aspect-ratio: 3/4;background-color: rgba(0, 0, 0, 0.1)">
                            <div class="loader-container"><span class="loader"></span></div>
                            <img src="assets/uploads/thumbnails/' . basename($product['thumbnail_image']) . '" width="100%" style="object-fit: cover;min-width: 100%;" alt="Product">';
                    if ($product['discounted_percentage'] < 1) {
                        echo '';
                    } else {
                        echo '<div class="position-absolute bg-danger text-white fw-bold" style="top: 10px; left: 10px; font-size: 12px; padding: 3px 10px; border-radius: 5px;">' . $product['discounted_percentage'] . '%</div>';
                    }
                    echo '<div class="discount_percentage_badge">QUICKVIEW</div>';
                    echo '</div>';
                    echo '<div class="text-black mt-2 lh-sm fw-bold">' . $product['title'] . '</div>';

                    if ($product['discounted_price'] < 1) {
                        echo '<div class="text-black mt-1 lh-sm fw-bold">Rs.' . $product['price'] . '</div>';
                    } else {
                        echo '<div class="d-flex align-items-center gap-2 mt-1">';
                        echo '<div class="text-black fw-bold">Rs.' . $product['discounted_price'] . '</div>';
                        echo '<div class="fw-bold text-decoration-line-through" style="color: gray;">Rs.' . $product['price'] . '</div>';
                        echo '</div>';
                    }
                    echo '</a>';
                }
                echo '</section>';

                echo '<nav aria-label="Page navigation" class="mb-4 mt-2">
                        <ul class="pagination justify-content-center">';
                for ($i = 1; $i <= $total_pages; $i++) {
                    echo '<li class="page-item ' . ($i == $current_page ? 'active' : '') . '">
                            <a class="page-link" href="?category=' . $category['link'] . '&page=' . $i . '">' . $i . '</a>
                          </li>';
                }
                echo '</ul>
                      </nav>';
            } else {
                echo '<div>No products found.</div>';
            }
            ?>
        </section>
    </main>


    <?php include('components/footer.php'); ?>
    <?php include('components/whatsapp.php'); ?>
    <?php include('components/popup.php'); ?>

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>

</body>

</html>