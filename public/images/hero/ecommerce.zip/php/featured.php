<?php
require('connection.php');

$base_sql = "SELECT DISTINCT p.thumbnail_image, p.title, p.slug, p.price, p.discounted_price, p.discounted_percentage, p.type, p.pieces FROM products p";
$base_sql .= " LEFT JOIN product_variants pv ON p.id = pv.product_id";
$base_sql .= " LEFT JOIN variants v ON pv.variant_id = v.id";

$selected_types = !empty($_GET['type']) ? $_GET['type'] : [];
$selected_pieces = !empty($_GET['piece']) ? $_GET['piece'] : [];
$selected_colors = !empty($_GET['color']) ? $_GET['color'] : [];
$selected_prices = !empty($_GET['price']) ? $_GET['price'] : [];

function generateConditions($selected_filters, $column_name)
{
    $conditions = [];
    foreach ($selected_filters as $filter) {
        $conditions[] = "$column_name = '$filter'";
    }
    return implode(" OR ", $conditions);
}

function generatePriceConditions($selected_prices)
{
    $price_conditions = [];
    foreach ($selected_prices as $price_range) {
        switch ($price_range) {
            case 'price1':
                $price_conditions[] = "(p.discounted_price > 0 AND p.discounted_price < 4000)";
                $price_conditions[] = "(p.discounted_price = 0 AND p.price < 4000)";
                break;
            case 'price2':
                $price_conditions[] = "(p.discounted_price > 0 AND p.discounted_price BETWEEN 4000 AND 8000)";
                $price_conditions[] = "(p.discounted_price = 0 AND p.price BETWEEN 4000 AND 8000)";
                break;
            case 'price3':
                $price_conditions[] = "(p.discounted_price > 0 AND p.discounted_price BETWEEN 8000 AND 12000)";
                $price_conditions[] = "(p.discounted_price = 0 AND p.price BETWEEN 8000 AND 12000)";
                break;
            case 'price4':
                $price_conditions[] = "(p.discounted_price > 0 AND p.discounted_price BETWEEN 12000 AND 16000)";
                $price_conditions[] = "(p.discounted_price = 0 AND p.price BETWEEN 12000 AND 16000)";
                break;
            case 'price5':
                $price_conditions[] = "(p.discounted_price > 0 AND p.discounted_price BETWEEN 16000 AND 20000)";
                $price_conditions[] = "(p.discounted_price = 0 AND p.price BETWEEN 16000 AND 20000)";
                break;
            case 'price6':
                $price_conditions[] = "(p.discounted_price > 0 AND p.discounted_price > 20000)";
                $price_conditions[] = "(p.discounted_price = 0 AND p.price > 20000)";
                break;
        }
    }
    return implode(" OR ", $price_conditions);
}


$type_condition = generateConditions($selected_types, 'p.type');
$piece_condition = generateConditions($selected_pieces, 'p.pieces');
$color_condition = generateConditions($selected_colors, 'v.id');
$price_condition = generatePriceConditions($selected_prices);

$where_conditions = [];
if (!empty($type_condition)) {
    $where_conditions[] = "($type_condition)";
}
if (!empty($piece_condition)) {
    $where_conditions[] = "($piece_condition)";
}
if (!empty($color_condition)) {
    $where_conditions[] = "($color_condition)";
}
if (!empty($price_condition)) {
    $where_conditions[] = "($price_condition)";
}

if (!empty($where_conditions)) {
    $base_sql .= " WHERE p.home_page = 1 AND " . implode(" AND ", $where_conditions);
} else {
    $base_sql .= " WHERE p.home_page = 1";
}

$base_sql .= " ORDER BY p.arrange ASC";

// Pagination
$results_per_page = 20;
$total_results_query = "SELECT COUNT(*) as total FROM ($base_sql) as filtered";
$total_results_result = mysqli_query($con, $total_results_query);
$total_results_row = mysqli_fetch_assoc($total_results_result);
$total_results = $total_results_row['total'];
$total_pages = ceil($total_results / $results_per_page);

$current_page = isset($_GET['page']) ? $_GET['page'] : 1;
$offset = ($current_page - 1) * $results_per_page;

$pagination_sql = $base_sql . " LIMIT $offset, $results_per_page";
$products = mysqli_query($con, $pagination_sql);

$color_sql = "SELECT id, name FROM variants WHERE type='color'";
$color_result = mysqli_query($con, $color_sql);

$product_types = [
    1 => "DYED W/O EMBROIDERED",
    2 => "DYED+EMBROIDERED",
    3 => "PASTED+EMBROIDERED",
    4 => "PASTED+PRINTED",
    5 => "PRINTED W/O EMBROIDERED",
    6 => "PRINTED+EMBROIDERED",
];

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-159HFH84B1"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'G-159HFH84B1');
    </script>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="images/favicon.ico" type="image/x-icon" />
    <title>Featured Products | Shopilic</title>

    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">

</head>

<body class="position-relative">

    <?php include('components/header.php'); ?>

    <nav style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='%236c757d'/%3E%3C/svg%3E&#34;);" aria-label="breadcrumb" class="px-4 mt-4 mb-2">
        <ol class="breadcrumb">
            <li class="breadcrumb-item fw-bold"><a href="index.php" class="text-decoration-none text-black">HOME</a></li>
            <li class="breadcrumb-item fw-bold active" aria-current="page">FEATURED</li>
        </ol>
    </nav>

    <div class="fs-3 fw-bold text-center px-3 mt-2 mb-3 mb-md-4">FEATURED PRODUCTS</div>

    <div class="text-center">
        <button class="btn btn-dark d-lg-none rounded-0 px-4" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasResponsive" aria-controls="offcanvasResponsive">Filters</button>
    </div>

    <main class="d-flex flex-column flex-lg-row gap-0 gap-md-4">
        <!-- Filters -->
        <section class="px-4 filters_sidebar pb-4">
            <div class="offcanvas-lg offcanvas-end" tabindex="-1" id="offcanvasResponsive" aria-labelledby="offcanvasResponsiveLabel">
                <div class="offcanvas-header">
                    <h5 class="offcanvas-title fw-bold" id="offcanvasResponsiveLabel">Filters</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" data-bs-target="#offcanvasResponsive" aria-label="Close"></button>
                </div>

                <div class="offcanvas-body d-flex flex-column gap-4">
                    <div>
                        <a href="featured.php" class="btn btn-outline-dark text-secondary" style="border-radius: 0px;padding: 2px 10px; font-weight: 500; border-color: gray;">Reset Filters</a>
                    </div>
                    <div>
                        <h6 class="fw-bold mb-3">Filter by Price</h6>
                        <div class="filters_checkbox">
                            <div>
                                <input type="checkbox" class="btn-check price-checkbox" id="price1" name="price[]" value="price1" autocomplete="off" <?php echo isset($_GET['price']) && in_array('price1', $_GET['price']) ? 'checked' : ''; ?>>
                                <label class="btn btn-outline-dark" for="price1">Less than 4,000</label>
                            </div>
                            <div>
                                <input type="checkbox" class="btn-check price-checkbox" id="price2" name="price[]" value="price2" autocomplete="off" <?php echo isset($_GET['price']) && in_array('price2', $_GET['price']) ? 'checked' : ''; ?>>
                                <label class="btn btn-outline-dark" for="price2">4,000 to 8,000</label>
                            </div>
                            <div>
                                <input type="checkbox" class="btn-check price-checkbox" id="price3" name="price[]" value="price3" autocomplete="off" <?php echo isset($_GET['price']) && in_array('price3', $_GET['price']) ? 'checked' : ''; ?>>
                                <label class="btn btn-outline-dark" for="price3">8,000 to 12,000</label>
                            </div>
                            <div>
                                <input type="checkbox" class="btn-check price-checkbox" id="price4" name="price[]" value="price4" autocomplete="off" <?php echo isset($_GET['price']) && in_array('price4', $_GET['price']) ? 'checked' : ''; ?>>
                                <label class="btn btn-outline-dark" for="price4">12,000 to 16,000</label>
                            </div>
                            <div>
                                <input type="checkbox" class="btn-check price-checkbox" id="price5" name="price[]" value="price5" autocomplete="off" <?php echo isset($_GET['price']) && in_array('price5', $_GET['price']) ? 'checked' : ''; ?>>
                                <label class="btn btn-outline-dark" for="price5">16,000 to 20,000</label>
                            </div>
                            <div>
                                <input type="checkbox" class="btn-check price-checkbox" id="price6" name="price[]" value="price6" autocomplete="off" <?php echo isset($_GET['price']) && in_array('price6', $_GET['price']) ? 'checked' : ''; ?>>
                                <label class="btn btn-outline-dark" for="price6">More than 20,000</label>
                            </div>
                        </div>
                    </div>
                    <div>
                        <h6 class="fw-bold mb-3">Filter by Color</h6>
                        <div class="filters_checkbox">
                            <?php
                            while ($row = mysqli_fetch_assoc($color_result)) {
                                $color_id = $row['id'];
                                $color_name = $row['name'];
                                $checked = isset($_GET['color']) && in_array($color_id, $_GET['color']) ? 'checked' : '';
                                echo '
        <div>
            <input type="checkbox" class="btn-check color-checkbox" id="color_' . $color_id . '" name="color[]" value="' . $color_id . '" autocomplete="off" ' . $checked . '>
            <label class="btn btn-outline-dark" for="color_' . $color_id . '">' . $color_name . '</label>
        </div>';
                            }
                            ?>
                        </div>
                    </div>
                    <div>
                        <h6 class="fw-bold mb-3">Filter by Piece</h6>
                        <div class="filters_checkbox">
                            <div>
                                <?php
                                $checked_2piece = isset($_GET['piece']) && in_array('2', $_GET['piece']) ? 'checked' : '';
                                ?>
                                <input type="checkbox" class="btn-check piece-checkbox" id="2piece" value="2" autocomplete="off" <?php echo $checked_2piece; ?>>
                                <label class="btn btn-outline-dark" for="2piece">2 Piece</label>
                            </div>
                            <div>
                                <?php
                                $checked_3piece = isset($_GET['piece']) && in_array('3', $_GET['piece']) ? 'checked' : '';
                                ?>
                                <input type="checkbox" class="btn-check piece-checkbox" id="3piece" value="3" autocomplete="off" <?php echo $checked_3piece; ?>>
                                <label class="btn btn-outline-dark" for="3piece">3 Piece</label>
                            </div>
                        </div>
                    </div>
                    <div>
                        <h6 class="fw-bold mb-3">Filter by Type</h6>
                        <div class="filters_checkbox">
                            <?php foreach ($product_types as $key => $value) : ?>
                                <div>
                                    <?php
                                    $checked = isset($_GET['type']) && in_array($key, $_GET['type']) ? 'checked' : '';
                                    ?>
                                    <input type="checkbox" class="btn-check product-type-checkbox" id="product_<?php echo $key; ?>" value="<?php echo $key; ?>" autocomplete="off" <?php echo $checked; ?>>
                                    <label class="btn btn-outline-dark" for="product_<?php echo $key; ?>"><?php echo $value; ?></label>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Products -->
        <section class="flex-grow-1">
            <!-- Products -->
            <section>
                <?php
                if (!empty($products)) {
                    echo '<section class="home_products mt-2 px-4 mb-4">';
                    foreach ($products as $product) {
                        echo '<a class="home_products_box text-decoration-none" href="product.php?product=' . $product['slug'] . '">';
                        echo '<div class="position-relative" style="aspect-ratio: 3/4;background-color: rgba(0, 0, 0, 0.1)">';
                        echo '<div class="loader-container"><span class="loader"></span></div>';
                        echo '<img src="assets/uploads/thumbnails/' . basename($product['thumbnail_image']) . '" width="100%" style="object-fit: cover;min-width: 100%;" alt="Product">';

                        if ($product['discounted_percentage'] < 1) {
                            echo '';
                        } else {
                            echo '<div class="position-absolute bg-danger text-white fw-bold" style="top: 10px; left: 10px; font-size: 12px; padding: 3px 10px; border-radius: 5px;">' . $product['discounted_percentage'] . '%</div>';
                        }
                        echo '<div class="discount_percentage_badge">QUICKVIEW</div>';
                        echo '</div>';
                        echo '<div class="text-black mt-2 lh-sm fw-bold">' . $product['title'] . '</div>';

                        if ($product['discounted_price'] < 1) {
                            echo '<div class="text-black mt-1 lh-sm fw-bold">Rs.' . $product['price'] . '</div>';
                        } else {
                            echo '<div class="d-flex align-items-center gap-2 mt-1">';
                            echo '<div class="text-black fw-bold">Rs.' . $product['discounted_price'] . '</div>';
                            echo '<div class="fw-bold text-decoration-line-through" style="color: gray;">Rs.' . $product['price'] . '</div>';
                            echo '</div>';
                        }
                        echo '</a>';
                    }
                    echo '</section>';
                } else {
                    echo '<div>No products found.</div>';
                }
                ?>
            </section>


            <!-- Pagination links -->
            <nav aria-label="Page navigation">
                <ul class="pagination justify-content-center">
                    <?php for ($i = 1; $i <= $total_pages; $i++) : ?>
                        <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                            <a class="page-link" href="featured.php?page=<?php echo $i; ?><?php echo generateFilterQueryString(); ?>"><?php echo $i; ?></a>
                        </li>
                    <?php endfor; ?>
                </ul>
            </nav>
        </section>
    </main>

    <?php
    function generateFilterQueryString()
    {
        $queryString = '';
        if (!empty($_GET['type'])) {
            $queryString .= '&type[]=' . implode('&type[]=', $_GET['type']);
        }
        if (!empty($_GET['piece'])) {
            $queryString .= '&piece[]=' . implode('&piece[]=', $_GET['piece']);
        }
        if (!empty($_GET['color'])) {
            $queryString .= '&color[]=' . implode('&color[]=', $_GET['color']);
        }
        if (!empty($_GET['price'])) {
            $queryString .= '&price[]=' . implode('&price[]=', $_GET['price']);
        }
        return $queryString;
    }
    ?>


    <?php include('components/footer.php'); ?>
    <?php include('components/whatsapp.php'); ?>
    <?php include('components/popup.php'); ?>

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>

    <script>
        const checkboxes = document.querySelectorAll('.product-type-checkbox, .piece-checkbox, .color-checkbox, .price-checkbox');
        checkboxes.forEach(checkbox => {
            checkbox.addEventListener('change', function() {
                const selectedTypes = [];
                const selectedPieces = [];
                const selectedColors = [];
                const selectedPrices = [];
                checkboxes.forEach(cb => {
                    if (cb.checked) {
                        if (cb.classList.contains('product-type-checkbox')) {
                            selectedTypes.push(cb.value);
                        } else if (cb.classList.contains('piece-checkbox')) {
                            selectedPieces.push(cb.value);
                        } else if (cb.classList.contains('color-checkbox')) {
                            selectedColors.push(cb.value);
                        } else if (cb.classList.contains('price-checkbox')) {
                            selectedPrices.push(cb.value);
                        }
                    }
                });
                const typeQueryString = selectedTypes.length > 0 ? 'type[]=' + selectedTypes.join('&type[]=') : '';
                const pieceQueryString = selectedPieces.length > 0 ? 'piece[]=' + selectedPieces.join('&piece[]=') : '';
                const colorQueryString = selectedColors.length > 0 ? 'color[]=' + selectedColors.join('&color[]=') : '';
                const priceQueryString = selectedPrices.length > 0 ? 'price[]=' + selectedPrices.join('&price[]=') : '';
                const queryString = [typeQueryString, pieceQueryString, colorQueryString, priceQueryString].filter(Boolean).join('&');
                window.location.href = 'featured.php' + (queryString ? '?' + queryString : '');
            });
        });
    </script>


</body>

</html>