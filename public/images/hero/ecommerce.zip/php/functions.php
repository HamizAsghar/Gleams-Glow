<?php
function pr($arr)
{
    echo '<pre>';
    print_r($arr);
}

function prx($arr)
{
    echo '<pre>';
    print_r($arr);
    die();
}

function get_safe_value($con, $str)
{
    if ($str != '') {
        return mysqli_real_escape_string($con, $str);
    }
}

function auth_admin()
{
    session_start();

    if (!isset($_SESSION["ADMIN_LOGIN"]) || $_SESSION["ADMIN_LOGIN"] !== "yes") {
        header("location: ../login.php");
        exit;
    }
}
