-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 12, 2024 at 07:20 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shopilic`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `banners`
--

CREATE TABLE `banners` (
  `id` int(11) NOT NULL,
  `desktop_image_path` varchar(255) NOT NULL,
  `mobile_image_path` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `arrange` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `banners`
--

INSERT INTO `banners` (`id`, `desktop_image_path`, `mobile_image_path`, `link`, `created_at`, `arrange`) VALUES
(6, '../../assets/uploads/66083cc6c0c64_360_F_465465254_1pN9MGrA831idD6zIBL7q8rnZZpUCQTy.jpg', '../../assets/uploads/66083cc6c1771_banner-and-eCommerce.jpg', 'category.php?category=unstitched', '2024-03-30 16:24:38', 1),
(10, '../../assets/uploads/662bdfc53147c_banner.webp', '../../assets/uploads/662bdfc531d9b_banner.jpg', 'products.php?type[]=1&type[]=3', '2024-04-26 17:09:25', 2),
(13, '../../assets/uploads/6635d1f6eedeb_360_F_392210928_JgmPZsGuKSye5FqOoCyjSGRTF7fJIgOS.jpg', '../../assets/uploads/6635d1f6eff79_sale-banner-template-design-600nw-487646614.webp', 'WOMEN', '2024-05-04 06:13:10', 3);

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `color_id` int(11) DEFAULT NULL,
  `size_id` int(11) DEFAULT NULL,
  `color_name` varchar(255) DEFAULT NULL,
  `size_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `ip_address`, `product_id`, `quantity`, `color_id`, `size_id`, `color_name`, `size_name`) VALUES
(59, '1', 5, 1, 0, NULL, 'Yellow', '');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `desktop_image_path` varchar(255) NOT NULL,
  `mobile_image_path` varchar(255) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `link` varchar(255) NOT NULL,
  `arrange` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `desktop_image_path`, `mobile_image_path`, `category_name`, `created_at`, `link`, `arrange`) VALUES
(5, '../../assets/uploads/6612bed19ac9e_fashion.jpg', '../../assets/uploads/6612bed19b42a_fashion-small.jpg', 'WOMEN', '2024-04-07 15:42:09', 'women', 1),
(12, '../../assets/uploads/6637bd9472e43_banner-and-eCommerce.jpg', '../../assets/uploads/6637bd947339b_banner-and-eCommerce.jpg', 'UNSTITCHED', '2024-05-05 17:10:44', 'unstitched', 2),
(13, '../../assets/uploads/6637bda5a15d4_360_F_392210928_JgmPZsGuKSye5FqOoCyjSGRTF7fJIgOS.jpg', '../../assets/uploads/6637bda5a1b7b_360_F_392210928_JgmPZsGuKSye5FqOoCyjSGRTF7fJIgOS.jpg', 'STITCHED', '2024-05-05 17:11:01', 'stitched', 3);

-- --------------------------------------------------------

--
-- Table structure for table `contactus`
--

CREATE TABLE `contactus` (
  `id` int(11) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `phonenumber` varchar(20) NOT NULL,
  `usermessage` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone_number` varchar(20) NOT NULL,
  `address` varchar(255) NOT NULL,
  `country` varchar(100) NOT NULL,
  `province` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `zip` varchar(20) NOT NULL,
  `message` text DEFAULT NULL,
  `order_date` datetime NOT NULL,
  `total_amount` int(11) NOT NULL,
  `order_status` varchar(50) NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `full_name`, `email`, `phone_number`, `address`, `country`, `province`, `city`, `zip`, `message`, `order_date`, `total_amount`, `order_status`) VALUES
(1002, 'John Doe', '', '03171112223', 'House 123, Nishat Abad', 'Pakistan', 'Punjab', 'Lahore', '16000', 'Hello this is an \r\n\r\nadditional meesage', '2024-05-08 12:35:45', 24798, 'pending'),
(1003, 'John Doe', 'you@example.com', '03171112223', 'House 123, Nishat Abad', 'Pakistan', 'Sindh', 'Karachi', '32000', '', '2024-05-08 12:38:41', 4800, 'shipped'),
(1004, 'Hello World', 'hello@email.com', '01234567', '1234 Main st', 'Pakistan', 'Sindh', 'Karachi', '24234', 'Karandi Partywear 03 Pieces Heavy Embroidered Patch Work', '2024-05-08 12:40:56', 10998, 'pending'),
(1005, 'Hello World', '', '03171112223', 'House 123, Nishat Abad', 'Pakistan', 'Punjab', 'Lahore', '15000', '', '2024-05-08 15:12:49', 4800, 'pending'),
(1006, 'John Doe', '', '03171112223', 'House 123, Nishat Abad', 'Pakistan', 'Punjab', 'Faisalabad', '14000', 'SPYKAR Women Pink Alexa Super Skinny Fit High-Rise Clean Look Stretchable Cropped Jeans', '2024-05-08 15:17:08', 28097, 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_title` varchar(255) NOT NULL,
  `color` varchar(50) DEFAULT NULL,
  `size` varchar(50) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `price_per_item` int(11) NOT NULL,
  `subtotal` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `product_title`, `color`, `size`, `quantity`, `price_per_item`, `subtotal`) VALUES
(1, 1002, 5, 'SPYKAR Women Pink Alexa Super Skinny Fit High-Rise Clean Look Stretchable Cropped Jeans ', 'Yellow', '', 1, 4800, 4800),
(2, 1002, 3, 'Karandi Partywear 03 Pieces Heavy Embroidered Patch Work', '', '', 2, 5499, 10998),
(3, 1002, 4, 'EthnoVogue Women Beige & Grey Made to Measure Custom Made Kurta Set with Jacket ', 'Red', 'Large', 1, 3000, 3000),
(4, 1002, 4, 'EthnoVogue Women Beige & Grey Made to Measure Custom Made Kurta Set with Jacket ', 'Red', 'Medium', 2, 3000, 6000),
(5, 1003, 5, 'SPYKAR Women Pink Alexa Super Skinny Fit High-Rise Clean Look Stretchable Cropped Jeans ', 'Yellow', '', 1, 4800, 4800),
(6, 1004, 3, 'Karandi Partywear 03 Pieces Heavy Embroidered Patch Work', '', '', 2, 5499, 10998),
(7, 1005, 5, 'SPYKAR Women Pink Alexa Super Skinny Fit High-Rise Clean Look Stretchable Cropped Jeans ', 'Yellow', '', 1, 4800, 4800),
(8, 1006, 5, 'SPYKAR Women Pink Alexa Super Skinny Fit High-Rise Clean Look Stretchable Cropped Jeans ', 'Yellow', '', 2, 4800, 9600),
(9, 1006, 3, 'Karandi Partywear 03 Pieces Heavy Embroidered Patch Work', '', '', 1, 5499, 5499),
(10, 1006, 1, 'Dhanak Partywear 03 Pieces Heavy Embroidered Patch', '', '', 2, 6499, 12998);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `thumbnail_image` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `price` int(11) NOT NULL,
  `discounted_price` int(11) DEFAULT NULL,
  `discounted_percentage` int(11) DEFAULT NULL,
  `pieces` int(11) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `home_page` tinyint(1) DEFAULT 0,
  `best_selling` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `date_view` date DEFAULT '1970-01-01',
  `views` int(11) DEFAULT 0,
  `arrange` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `thumbnail_image`, `title`, `slug`, `description`, `price`, `discounted_price`, `discounted_percentage`, `pieces`, `type`, `home_page`, `best_selling`, `created_at`, `date_view`, `views`, `arrange`) VALUES
(1, '6637afc65e343_0003642_kesari.jpg', 'Dhanak Partywear 03 Pieces Heavy Embroidered', 'dhanak-partywear-03-pieces-heavy-embroidered', 'Item Code= Bareeze-DH-3356. - Shirt= Dhanak Fancy Embroidered Shirt With Neck & Daman Patch, Embroidered Sleeves & Plain Dyed Back. - Dupatta= Dhanak Heavy Embroidered Shawl with 4 side Border', 13500, 6499, 50, 3, '1', 0, 1, '2024-04-11 17:36:36', '2024-05-08', 2, 3),
(2, '6618216e395ba_pakistanidesignerdresses-1667698071285.jpeg.jpg', 'Linen Partywear 03 Pieces Heavy Embroidered Patch Work', 'linen-partywear-03-pieces-heavy-embroidered-patch', 'Item Code= AK-Bareeze-LN-2353. - Shirt= Linen Fancy Embroidered Shirt With Neck & Daman Patch, Embroidered Sleeves & Plain Dyed Back. - Dupatta= Bamber Shiffon Embroidered Dupatta. - Trouser= Plain Dyed', 10500, 0, 0, 0, '0', 1, 1, '2024-04-11 17:44:14', '2024-05-08', 1, 2),
(3, '661a91be138a6_CS5_600x_crop_center_65efdd7c-6e12-4756-8038-5c193177d516.jpg', 'Karandi Partywear 03 Pieces Heavy Embroidered Patch Work', 'karandi-partywear-03-pieces-heavy-embroidered-patch-work', 'Item Code= Bareeze-KR-3230. - Shirt= Karandi Fancy Embroidered Shirt With Neck & Daman Patch, Embroidered Sleeves & Plain Dyed Back. - Dupatta= Karandi Heavy Embroidered Shawl. - Trouser= Plain Dyed', 11000, 5499, 50, 3, '4', 0, 0, '2024-04-13 14:07:58', '2024-05-08', 5, 1),
(4, '66291e6da8cba_WhatsAppImage2022-09-20at3.20.39PM_1_1000x.jpg', 'EthnoVogue Women Beige & Grey Made to Measure Custom Made Kurta Set Jacket ', 'ethnovogue-women-beige--grey-made-to-measure-custom-made-kurta-set-jacket-', 'EthnoVogue Women \r\nBeige & Grey Made to Measure Custom Made Kurta Set ', 7500, 4000, 50, 2, '3', 1, 1, '2024-04-24 14:59:57', '2024-05-08', 2, 0),
(5, '66291edc27da6_sb-12qurbat-2-1800x1800.jpg', 'SPYKAR Women Pink Alexa Super Skinny Fit High-Rise Clean Look Stretchable Cropped Jeans ', 'spykar-women-pink-alexa-super-skinny-fit-high-rise-clean-look-stretchable-cropped-jeans-', 'SPYKAR Women Pink Alexa Super Skinny Fit High-Rise Clean Look Stretchable Cropped Jeans ', 4800, 0, 0, 0, '0', 1, 1, '2024-04-24 15:01:48', '2024-05-12', 2, 0),
(10, '663bacf32c135_harry-cunningham-7qCeFo19r24-unsplash.jpg', 'This is dummy product for testing', 'this-is-dummy-product-for-testing', 'This is dummy product for testing', 15000, 7500, 50, 2, '6', 1, 1, '2024-05-08 16:48:51', '2024-05-12', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `product_categories`
--

CREATE TABLE `product_categories` (
  `id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_categories`
--

INSERT INTO `product_categories` (`id`, `product_id`, `category_id`) VALUES
(2, 1, 5),
(26, 1, 13),
(3, 2, 5),
(16, 3, 5),
(15, 3, 12),
(17, 3, 13),
(31, 4, 5),
(19, 4, 13),
(25, 5, 5),
(28, 10, 5),
(29, 10, 12),
(30, 10, 13);

-- --------------------------------------------------------

--
-- Table structure for table `product_images`
--

CREATE TABLE `product_images` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `image_path` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_images`
--

INSERT INTO `product_images` (`id`, `product_id`, `image_path`) VALUES
(1, 1, '66181fa4d0e89_0003642_kesari.jpg'),
(2, 1, '66181fa4d0e89_0003643_kesari.jpg'),
(3, 1, '66181fa4d0e89_0003644_kesari.jpg'),
(4, 2, '6618216e395ba_pakistanidesignerdresses-1667698071335.jpeg.jpg'),
(5, 2, '6618216e395ba_pakistanidesignerdresses-1667698071353.jpeg.jpg'),
(6, 2, '6618216e395ba_pakistanidesignerdresses-1667698071462.jpeg.jpg'),
(7, 2, '6618216e395ba_pakistanidesignerdresses-1667698071467.jpeg.jpg'),
(8, 3, '661a91be138a6_CS1_600x_crop_center_82d254f4-6e6b-4658-abe7-ab3984f4be47.jpg'),
(9, 3, '661a91be138a6_CS3_600x_crop_center_b1b56964-d39e-4c2e-bed0-ec3db18bd768.jpg'),
(10, 3, '661a91be138a6_CS5_600x_crop_center_65efdd7c-6e12-4756-8038-5c193177d516.jpg'),
(11, 4, '66291e6da8cba_WhatsAppImage2022-09-20at3.20.39PM_1_1000x.jpg'),
(12, 4, '66291e6da8cba_WhatsAppImage2022-09-20at3.20.40PM_1_1000x.jpg'),
(13, 4, '66291e6da8cba_WhatsAppImage2022-09-20at3.20.40PM_1000x.jpg'),
(14, 5, '66291edc27da6_sb-12qurbat-2-1800x1800.jpg'),
(15, 5, '66291edc27da6_sb-12qurbat-4-1800x1800.jpg'),
(16, 5, '66291edc27da6_sb-12qurbat-12-1800x1800.jpg'),
(24, 10, '663bacf32c135_harry-cunningham-7qCeFo19r24-unsplash.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `product_variants`
--

CREATE TABLE `product_variants` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `variant_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_variants`
--

INSERT INTO `product_variants` (`id`, `product_id`, `variant_id`) VALUES
(22, 4, 17),
(23, 4, 18),
(24, 4, 19),
(25, 4, 13),
(26, 5, 16);

-- --------------------------------------------------------

--
-- Table structure for table `variants`
--

CREATE TABLE `variants` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` enum('color','size') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `variants`
--

INSERT INTO `variants` (`id`, `name`, `type`) VALUES
(13, 'Red', 'color'),
(14, 'Blue', 'color'),
(15, 'Green', 'color'),
(16, 'Yellow', 'color'),
(17, 'Small', 'size'),
(18, 'Medium', 'size'),
(19, 'Large', 'size');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `banners`
--
ALTER TABLE `banners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contactus`
--
ALTER TABLE `contactus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_slug` (`slug`);

--
-- Indexes for table `product_categories`
--
ALTER TABLE `product_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `product_id` (`product_id`,`category_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `product_images`
--
ALTER TABLE `product_images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `product_variants`
--
ALTER TABLE `product_variants`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `variant_id` (`variant_id`);

--
-- Indexes for table `variants`
--
ALTER TABLE `variants`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `banners`
--
ALTER TABLE `banners`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `contactus`
--
ALTER TABLE `contactus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1007;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `product_categories`
--
ALTER TABLE `product_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `product_images`
--
ALTER TABLE `product_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `product_variants`
--
ALTER TABLE `product_variants`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `variants`
--
ALTER TABLE `variants`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`);

--
-- Constraints for table `product_categories`
--
ALTER TABLE `product_categories`
  ADD CONSTRAINT `product_categories_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  ADD CONSTRAINT `product_categories_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`);

--
-- Constraints for table `product_images`
--
ALTER TABLE `product_images`
  ADD CONSTRAINT `product_images_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `product_variants`
--
ALTER TABLE `product_variants`
  ADD CONSTRAINT `product_variants_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  ADD CONSTRAINT `product_variants_ibfk_2` FOREIGN KEY (`variant_id`) REFERENCES `variants` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
