<?php
require('connection.php');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-159HFH84B1"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'G-159HFH84B1');
    </script>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="images/favicon.ico" type="image/x-icon" />
    <title>Shopilic - Search</title>

    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">

</head>

<body class="position-relative">

    <?php include('components/header.php'); ?>

    <main>
        <?php
        if (isset($_GET['keyword'])) {
            // Escape the keyword to prevent SQL injection
            $keyword = '%' . $_GET['keyword'] . '%';

            // Prepare the SQL statement to count the number of matching rows
            $countStmt = "SELECT COUNT(*) AS numrows FROM products WHERE title LIKE ?";
            $countResult = $con->prepare($countStmt);
            $countResult->bind_param("s", $keyword);
            $countResult->execute();
            $countRow = $countResult->get_result()->fetch_assoc();
            $numrows = $countRow['numrows'];

            if ($numrows < 1) {
                echo '<h4 class="text-center p-4">No results found for <i>' . $_GET['keyword'] . '</i></h4>';
            } else {
                echo '<h4 class="text-center p-4">Search results for <i>' . $_GET['keyword'] . '</i></h4>';

                // Prepare the SQL statement to fetch the matching rows
                $stmt = $con->prepare("SELECT id, title, slug, thumbnail_image, price, discounted_price, discounted_percentage FROM products WHERE title LIKE ?");
                $stmt->bind_param("s", $keyword);
                $stmt->execute();
                $result = $stmt->get_result();

                echo '
        <section class="home_products mt-2 px-4 mb-4">';
                while ($row = $result->fetch_assoc()) {
                    $highlighted = preg_filter('/' . preg_quote($_GET['keyword'], '/') . '/i', '<b>$0</b>', $row['title']);
                    $image = (!empty($row['thumbnail_image'])) ? 'assets/uploads/thumbnails/' . $row['thumbnail_image'] : '';

                    echo '
                        <a class="home_products_box text-decoration-none" href="product.php?product=' . $row['slug'] . '">
            <div class="position-relative" style="aspect-ratio: 3/4;background-color: rgba(0, 0, 0, 0.1)">
            <div class="loader-container"><span class="loader"></span></div>
            <img src="' . $image . '" width="100%" style="object-fit: cover;min-width: 100%;" alt="Product">
                ';

                    if ($row['discounted_percentage'] < 1) {
                        echo '';
                    } else {
                        echo '<div class="position-absolute bg-danger text-white fw-bold" style="top: 10px; left: 10px; font-size: 12px; padding: 3px 10px; border-radius: 5px;">30%</div>';
                    }
                    echo '<div class="discount_percentage_badge">QUICKVIEW</div>
            </div>
            <div class="text-black mt-2 lh-sm fw-bold">' . $row['title'] . '</div>';

                    if ($row['discounted_price'] < 1) {
                        echo '<div class="text-black mt-1 lh-sm fw-bold">Rs.' . $row['price'] . '</div>';
                    } else {
                        echo '<div class="d-flex align-items-center gap-2 mt-1">
                <div class="text-black fw-bold">Rs.' . $row['discounted_price'] . '</div>
                <div class="fw-bold text-decoration-line-through" style="color: gray;">Rs.' . $row['price'] . '</div>
                </div>';
                    }

                    echo '</a>
                        ';
                }
                echo '</section>';
            }
        } else {
            echo '<h4 class="text-center p-4">No keyword provided</h4>';
        }
        ?>

        <!-- <div class="col-sm-4">
                            <div class="box box-solid">
                                <div class="box-body prod-body">
                                    <img src="' . $image . '" width="100%" height="230px" class="thumbnail">
                                    <h5><a href="product.php?product=' . $row['slug'] . '">' . $highlighted . '</a></h5>
                                </div>
                                <div class="box-footer">
                                    <b>&#36; ' . number_format($row['price'], 2) . '</b>
                                </div>
                            </div>
                        </div> -->

    </main>

    <?php include('components/footer.php'); ?>
    <?php include('components/whatsapp.php'); ?>
    <?php include('components/popup.php'); ?>

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>

</body>

</html>