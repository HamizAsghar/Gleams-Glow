<?php
require('connection.php');

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $fullname = htmlspecialchars($_POST['fullname'] ?? '');
    $phonenumber = htmlspecialchars($_POST['phonenumber'] ?? '');
    $usermessage = htmlspecialchars($_POST['usermessage'] ?? '');

    $sql = "INSERT INTO contactus (fullname, phonenumber, usermessage) VALUES (?, ?, ?)";

    $stmt = mysqli_prepare($con, $sql);
    mysqli_stmt_bind_param($stmt, "sss", $fullname, $phonenumber, $usermessage);

    if (mysqli_stmt_execute($stmt)) {
        $_SESSION['successMessage'] = "Your message has been sent successfully. Our team will contact you as soon as possible.";
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit();
    } else {
        $_SESSION['successMessage'] = "Error: Unable to send message. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="images/favicon.ico" type="image/x-icon" />
    <title>Contact | Shopilic</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
</head>

<body>

    <?php include('components/header.php'); ?>

    <div class="container-fluid px-3 ps-lg-5 mt-5">
        <div class="contactus_heading">CONTACT US</div>
    </div>

    <main class="container-fluid">
        <div class="row mb-5">
            <div class="col-md-7 col-12 px-3 pe-lg-0 ps-lg-5">
                <div class="contactus_text mb-5">
                    <div>Have a question or comment?</div>
                    <div>Use the form below to send us a message.</div>
                </div>
                <form class="contactus_form" id="contactForm" method="post">
                    <div>
                        <input type="text" placeholder="Full Name" id="name" name="fullname" required />
                    </div>
                    <div>
                        <input type="tel" placeholder="Phone Number" id="phonenumber" name="phonenumber" required />
                        <label for="phonenumber">(without dashes and space) i.e 03001234567</label>
                    </div>
                    <div>
                        <textarea placeholder="Message" rows="5" id="usermessage" name="usermessage" required></textarea>
                    </div>
                    <div>
                        <button type="submit">Send Message</button>
                    </div>
                </form>
                <?php if (isset($_SESSION['successMessage'])) : ?>
                    <div class="alert alert-success mt-4"><?php echo $_SESSION['successMessage']; ?></div>
                    <?php unset($_SESSION['successMessage']); ?>
                <?php endif; ?>
            </div>
            <div class="col-12 col-sm-9 col-md-5 px-4 m-auto px-lg-5">
                <img src="./assets/images/contact.svg" width="100%" alt="contactus" />
            </div>
        </div>
    </main>

    <?php include('components/footer.php'); ?>
    <?php include('components/whatsapp.php'); ?>
    <?php include('components/popup.php'); ?>

</body>

</html>