<?php
require('connection.php');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-159HFH84B1"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'G-159HFH84B1');
    </script>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="images/favicon.ico" type="image/x-icon" />
    <title>Shopilic</title>

    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">

</head>

<body class="position-relative">

    <?php include('components/header.php'); ?>

    <main>
        <!-- Banner -->
        <?php include('components/banner.php'); ?>

        <!-- Categories -->
        <?php include('components/category.php'); ?>

        <!-- Products -->
        <?php include('components/home-products.php'); ?>

    </main>

    <?php include('components/footer.php'); ?>
    <?php include('components/whatsapp.php'); ?>
    <?php include('components/popup.php'); ?>

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/index.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>

</body>

</html>