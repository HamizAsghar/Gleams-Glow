<?php

include("./layout.php");

require('connection.php');
$fetch_category_sql = "SELECT id, category_name FROM categories";
$categories = mysqli_query($con, $fetch_category_sql);

?>

<section>
    <h3 class="text-center">ADD NEW PRODUCT</h3>

    <form class="add_product_form mt-3" action="product-controllers/add-product.php" method="POST" enctype="multipart/form-data">
        <div>
            <label for="thumbnail_image">Thumbnail Image</label>
            <input type="file" name="thumbnail_image" id="thumbnail_image" required accept="image/*" />
        </div>
        <div>
            <label for="product_images">Product Images</label>
            <input type="file" name="product_images[]" id="product_images" required multiple accept="image/*" />
        </div>
        <div>
            <label for="title">Title</label>
            <input type="text" name="title" id="title" required />
        </div>
        <div>
            <label for="description">Description</label>
            <textarea name="description" id="description" required></textarea>
        </div>
        <div>
            <label for="price">Price</label>
            <input type="number" name="price" id="price" min="0" step="1" required />
        </div>
        <div>
            <label for="discounted_price">Discounted Price</label>
            <input type="number" name="discounted_price" id="discounted_price" min="0" step="1" required />
        </div>
        <div>
            <label for="discounted_percentage">Discounted Percentage</label>
            <input type="number" name="discounted_percentage" id="discounted_percentage" min="0" max="100" required />
        </div>
        <div>
            <label for="categories">Category</label>
            <select name="categories[]" id="categories" multiple required>
                <option value="">Select Category</option>
                <?php
                if (mysqli_num_rows($categories) > 0) {
                    while ($row = mysqli_fetch_assoc($categories)) {
                        echo '<option value="' . $row['id'] . '">' . $row['category_name'] . '</option>';
                    }
                }
                ?>
            </select>
        </div>
        <div>
            <label for="pieces">Pieces</label>
            <select name="pieces" id="pieces" required>
                <option value="" disabled>Select Piece</option>
                <option value="0">None</option>
                <option value="2">2 Piece</option>
                <option value="3">3 Piece</option>
            </select>
        </div>
        <div>
            <label for="type">Type</label>
            <select name="type" id="type" required>
                <option value="" disabled>Select Type</option>
                <option value="0">None</option>
                <option value="1">DYED W/O EMBROIDERED</option>
                <option value="2">DYED+EMBROIDERED</option>
                <option value="3">PASTED+EMBROIDERED</option>
                <option value="4">PASTED+PRINTED</option>
                <option value="5">PRINTED W/O EMBROIDERED</option>
                <option value="6">PRINTED+EMBROIDERED</option>
            </select>
        </div>
        <div class="form-check d-flex align-items-center flex-row gap-2">
            <input class="form-check-input" type="checkbox" name="home_page" id="home_page" value="1">
            <label class="form-check-label" for="home_page">Display on Home Page</label>
        </div>
        <div class="form-check d-flex align-items-center flex-row gap-2">
            <input class="form-check-input" type="checkbox" name="best_selling" id="best_selling" value="1">
            <label class="form-check-label" for="best_selling">Best Selling</label>
        </div>
        <!-- <div>
            <label for="home_page">Home Page</label>
            <select name="home_page" id="home_page" required>
                <option value="yes">Yes</option>
                <option value="no">No</option>
            </select>
        </div>
        <div>
            <label for="best_selling">Best Selling</label>
            <select name="best_selling" id="best_selling" required>
                <option value="yes">Yes</option>
                <option value="no">No</option>
            </select>
        </div> -->
        <div class="add_product_btn"><button class="btn btn-success fw-bold text-uppercase" type="submit">Add Product</button></div>
    </form>

</section>

<?php include("./layout-end.php"); ?>