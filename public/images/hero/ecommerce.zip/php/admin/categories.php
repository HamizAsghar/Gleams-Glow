<?php include("./layout.php"); ?>

<section>
    <h3 class="text-center">CATEGORIES</h3>

    <h4 class="mt-3">Add New Category:</h4>
    <form class="admin_banner_add_form" action="category-controllers/add-category.php" method="post" enctype="multipart/form-data">
        <div>
            <label for="desktop_image">Desktop Image:</label>
            <input type="file" name="desktop_image" id="desktop_image" accept="image/*" required>
        </div>
        <div>
            <label for="mobile_image">Mobile Image:</label>
            <input type="file" name="mobile_image" id="mobile_image" accept="image/*" required>
        </div>
        <div>
            <label for="category_name">Category Name:</label>
            <input type="text" name="category_name" id="category_name" required>
        </div>
        <button class="btn btn-outline-success fw-bold" type="submit" name="submit">Add Category</button>
    </form>
    
    <?php include('category-controllers/show-category.php'); ?>
</section>


<?php include("./layout-end.php"); ?>