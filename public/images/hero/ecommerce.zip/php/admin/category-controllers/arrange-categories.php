<?php
require('../connection.php');

// Check if data is received
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Decode JSON data
    $requestData = json_decode(file_get_contents('php://input'), true);

    // Check if data is valid
    if (is_array($requestData)) {
        // Prepare SQL statement to update arrange values
        $updateSql = "UPDATE categories SET arrange = ? WHERE id = ?";
        $stmt = mysqli_prepare($con, $updateSql);

        // Check if statement is prepared successfully
        if ($stmt) {
            // Bind parameters
            mysqli_stmt_bind_param($stmt, 'ii', $arrange, $categoryId);

            // Loop through each category data
            foreach ($requestData as $data) {
                $categoryId = $data['id'];
                $arrange = $data['arrange'];

                // Execute the statement for each category
                if (!mysqli_stmt_execute($stmt)) {
                    // Handle execution error
                    http_response_code(500);
                    echo json_encode(array('message' => 'Failed to update category arrangement.'));
                    exit;
                }
            }

            // Close statement
            mysqli_stmt_close($stmt);

            // Success response
            http_response_code(200);
            echo json_encode(array('message' => 'Category arrangement saved successfully.'));
        } else {
            // Error preparing statement
            http_response_code(500);
            echo json_encode(array('message' => 'Failed to prepare SQL statement.'));
        }
    } else {
        // Invalid data format
        http_response_code(400);
        echo json_encode(array('message' => 'Invalid data format.'));
    }
} else {
    // Invalid request method
    http_response_code(405);
    echo json_encode(array('message' => 'Method Not Allowed'));
}
?>