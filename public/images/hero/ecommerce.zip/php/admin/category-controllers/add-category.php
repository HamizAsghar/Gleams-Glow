<?php
require('../connection.php');

if (isset($_POST['submit'])) {
    if (!empty($_FILES['desktop_image']['name']) && !empty($_FILES['mobile_image']['name']) && !empty($_POST['category_name'])) {
        // Define upload directory
        $uploadDir = '../../assets/uploads/';

        // Upload desktop image
        $desktopImagePath = uploadImage($_FILES['desktop_image'], $uploadDir);

        // Upload mobile image
        $mobileImagePath = uploadImage($_FILES['mobile_image'], $uploadDir);

        // Get other form data
        $category_name = $_POST['category_name'];

        // Generate link from category name
        $link = strtolower(str_replace(' ', '', $category_name));

        // Check if link is unique
        $sqlCheckUniqueLink = "SELECT * FROM categories WHERE link = '$link'";
        $resultCheckUniqueLink = mysqli_query($con, $sqlCheckUniqueLink);
        $count = mysqli_num_rows($resultCheckUniqueLink);
        if ($count > 0) {
            $link .= '_' . uniqid(); // Append unique identifier if link is not unique
        }

        // Save the image details to MySQL if images were successfully uploaded
        if ($desktopImagePath && $mobileImagePath) {
            $sql = "INSERT INTO categories (desktop_image_path, mobile_image_path, category_name, link) VALUES ('$desktopImagePath', '$mobileImagePath', '$category_name', '$link')";
            if (mysqli_query($con, $sql)) {
                header("Location: ../categories.php");
                exit();
            } else {
                echo "Error: " . $sql . "<br>" . mysqli_error($con);
            }
        } else {
            echo "Failed to upload images.";
        }
    } else {
        echo "All input fields are required.";
    }
}

function uploadImage($file, $uploadDir)
{
    $filename = uniqid() . '_' . basename($file['name']);
    $targetFilePath = $uploadDir . $filename;

    if (move_uploaded_file($file['tmp_name'], $targetFilePath)) {
        return $targetFilePath;
    }
    return false;
}





// require('../connection.php');

// if (isset($_POST['submit'])) {
//     if (!empty($_FILES['desktop_image']['name']) && !empty($_FILES['mobile_image']['name']) && !empty($_POST['category_name'])) {
//         $uploadDir = '../../assets/uploads/';

//         $desktopImagePath = uploadImage($_FILES['desktop_image'], $uploadDir);

//         $mobileImagePath = uploadImage($_FILES['mobile_image'], $uploadDir);

//         $category_name = $_POST['category_name'];

//         if ($desktopImagePath && $mobileImagePath) {
//             $sql = "INSERT INTO categories (desktop_image_path, mobile_image_path, category_name) VALUES ('$desktopImagePath', '$mobileImagePath', '$category_name')";
//             if (mysqli_query($con, $sql)) {
//                 header("Location: ../categories.php");
//                 exit();
//             } else {
//                 echo "Error: " . $sql . "<br>" . mysqli_error($con);
//             }
//         } else {
//             echo "Failed to upload images.";
//         }
//     } else {
//         echo "All input fields are required.";
//     }
// }

// function uploadImage($file, $uploadDir)
// {
//     $filename = uniqid() . '_' . basename($file['name']);
//     $targetFilePath = $uploadDir . $filename;

//     if (move_uploaded_file($file['tmp_name'], $targetFilePath)) {
//         return $targetFilePath;
//     }
//     return false;
// }
