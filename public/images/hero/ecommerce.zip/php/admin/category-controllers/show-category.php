<?php
require('connection.php');

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['updateTextForm'])) {
    $categoryId = $_POST['categoryId'];
    $categoryText = $_POST['categoryText'];

    // Generate link from updated category name
    $link = strtolower(str_replace(' ', '', $categoryText));

    // Check if link is unique
    $sqlCheckUniqueLink = "SELECT * FROM categories WHERE link = '$link' AND id != $categoryId";
    $resultCheckUniqueLink = mysqli_query($con, $sqlCheckUniqueLink);
    $count = mysqli_num_rows($resultCheckUniqueLink);
    if ($count > 0) {
        $link .= '_' . uniqid();
    }

    // Update category name and link
    $sql = "UPDATE categories SET category_name = '$categoryText', link = '$link' WHERE id = $categoryId";
    if (mysqli_query($con, $sql)) {
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($con);
    }
}

?>

<section class="my-3">
    <h4 class="">All Categories:</h4>
    <div class="mt-3 d-flex flex-column gap-3">
        <?php
        $sql = "SELECT * FROM categories";
        $result = mysqli_query($con, $sql);

        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                echo '<div class="d-flex admin_category_container" data-category-id="' . $row['id'] . '" style="border: 1px solid silver; border-radius: 10px;">
                <div class="p-2 d-flex flex-wrap gap-3 justify-content-evenly flex-grow-1">
                    <div>
                        <div class="fw-bold" style="color: gray;">Category Name:</div>
                        <div class="fw-bold d-flex flex-column" data-category-id="' . $row['id'] . '">
                            <span class="editable" contenteditable="true">' . htmlspecialchars($row['category_name']) . '</span>
                            <button class="btn btn-outline-dark btn-sm update-name-btn mt-2">Update</button>
                        </div>
                    </div>
                    <div>
                        <div class="fw-bold" style="color: gray;">Desktop Image:</div>
                        <div class="pt-1" style="max-width: 250px;"><img style="border-radius: 5px;" src="../assets/uploads/' . basename($row['desktop_image_path']) . '" width="100%" alt="Category"></div>
                    </div>
                    <div>
                        <div class="fw-bold" style="color: gray;">Mobile Image:</div>
                        <div class="pt-1" style="max-width: 250px;"><img style="border-radius: 5px;" src="../assets/uploads/' . basename($row['mobile_image_path']) . '" width="100%" alt="Category"></div>
                    </div>
            </div>
            <button class="admin_category_del_btn fw-bold text-center p-2 border-0 outline-0" style="writing-mode: tb; transform: rotate(-180deg); border-bottom-left-radius: 9px; border-top-left-radius: 10px;">DELETE</button>
            </div>';
            }
        } else {
            echo '<div class="d-flex justify-content-center align-items-center">No categories available.</div>';
        }
        ?>
    </div>
</section>

<script>
    document.querySelectorAll('.update-name-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            var categoryId = this.parentElement.dataset.categoryId;
            var newName = this.parentElement.querySelector('.editable').innerText;

            // AJAX request to update the name
            var xhr = new XMLHttpRequest();
            xhr.open('POST', '<?php echo $_SERVER['PHP_SELF']; ?>', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.onreadystatechange = function() {
                if (xhr.readyState === XMLHttpRequest.DONE) {
                    if (xhr.status === 200) {
                        console.log('name updated successfully');
                    } else {
                        console.error('Failed to update name');
                    }
                }
            };
            xhr.send('updateTextForm=true&categoryId=' + encodeURIComponent(categoryId) + '&categoryText=' + encodeURIComponent(newName));
        });
    });
</script>