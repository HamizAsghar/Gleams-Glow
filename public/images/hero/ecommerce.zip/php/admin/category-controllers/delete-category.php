<?php
require('../connection.php');

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["category_id"])) {
    $categoryId = $_POST["category_id"];

    // Fetch category information to get image paths
    $sql_select = "SELECT desktop_image_path, mobile_image_path FROM categories WHERE id = ?";
    $stmt_select = mysqli_prepare($con, $sql_select);

    if ($stmt_select) {
        mysqli_stmt_bind_param($stmt_select, "i", $categoryId);
        mysqli_stmt_execute($stmt_select);
        mysqli_stmt_store_result($stmt_select);

        if (mysqli_stmt_num_rows($stmt_select) > 0) {
            mysqli_stmt_bind_result($stmt_select, $desktopImagePath, $mobileImagePath);
            mysqli_stmt_fetch($stmt_select);

            // Delete desktop image
            if (unlink($desktopImagePath)) {
                // Desktop image deleted successfully
            } else {
                // Error deleting desktop image
                echo "Error deleting desktop image";
            }

            // Delete mobile image
            if (unlink($mobileImagePath)) {
                // Mobile image deleted successfully
            } else {
                // Error deleting mobile image
                echo "Error deleting mobile image";
            }

            // Now, delete rows from product_categories table where category_id matches
            $sql_delete_products = "DELETE FROM product_categories WHERE category_id = ?";
            $stmt_delete_products = mysqli_prepare($con, $sql_delete_products);

            if ($stmt_delete_products) {
                mysqli_stmt_bind_param($stmt_delete_products, "i", $categoryId);

                if (mysqli_stmt_execute($stmt_delete_products)) {
                    // Now, delete category record from the categories table
                    $sql_delete_category = "DELETE FROM categories WHERE id = ?";
                    $stmt_delete_category = mysqli_prepare($con, $sql_delete_category);

                    if ($stmt_delete_category) {
                        mysqli_stmt_bind_param($stmt_delete_category, "i", $categoryId);

                        if (mysqli_stmt_execute($stmt_delete_category)) {
                            echo "Category and associated images deleted successfully.";
                        } else {
                            echo "Error deleting category record: " . mysqli_error($con);
                        }

                        mysqli_stmt_close($stmt_delete_category);
                    } else {
                        echo "Error preparing delete statement for category record: " . mysqli_error($con);
                    }
                } else {
                    echo "Error deleting rows from product_categories table: " . mysqli_error($con);
                }

                mysqli_stmt_close($stmt_delete_products);
            } else {
                echo "Error preparing delete statement for product_categories table: " . mysqli_error($con);
            }
        } else {
            // Category not found
            echo "Category not found.";
        }

        mysqli_stmt_close($stmt_select);
    } else {
        // Error preparing select statement
        echo "Error preparing select statement: " . mysqli_error($con);
    }
} else {
    // Invalid request or missing parameters
    echo "Invalid request";
}

// Close connection
mysqli_close($con);
