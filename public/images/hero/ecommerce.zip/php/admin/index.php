<?php include("./layout.php");
require('connection.php'); ?>

<section>
    <h3 class="text-center">ADMIN DASHBOARD</h3>

    <!-- Pending Orders -->
    <?php include('home-controllers/pending-order.php'); ?>

    <!-- Most Viewed Products -->
    <?php include('home-controllers/most-viewed.php'); ?>
</section>

<?php include("./layout-end.php"); ?>