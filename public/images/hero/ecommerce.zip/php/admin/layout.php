<?php
require('../functions.php');
auth_admin();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="images/favicon.ico" type="image/x-icon" />
    <title>Admin | Shopilic</title>

    <link rel="stylesheet" href="./assets/css/style.css">
    <link rel="stylesheet" href="./../assets/css/bootstrap.min.css">

</head>

<body>

    <nav class="navbar bg-body-tertiary" style="z-index: 9;">
        <div class="container-fluid">
            <a class="navbar-brand" href=""><img src="../assets/images/logo.png" width="130px" alt="logo" /></a>
            <button class="navbar-toggler admin_sidebar_btn" data-bs-toggle="offcanvas" data-bs-target="#offcanvasScrolling" aria-controls="offcanvasScrolling" type="button">
                <span class="navbar-toggler-icon"></span>
            </button>
            <form class="d-flex ms-auto" action="logout.php" method="post">
                <button class="btn btn-outline-dark fw-bold px-3" type="submit" name="logout">Logout</button>
            </form>
        </div>
    </nav>

    <main class="d-flex">
        <aside class="offcanvas offcanvas-start show" style="width: 300px;" data-bs-scroll="true" data-bs-backdrop="false" tabindex="-1" id="offcanvasScrolling" aria-labelledby="offcanvasScrollingLabel">
            <div class="offcanvas-header">
                <a class="navbar-brand" href=""><img src="../assets/images/logo.png" width="130px" alt="logo" /></a>
                <button type="button" class="btn-close shadow-none admin_sidebar_btn" data-bs-dismiss="offcanvas" aria-label="Close"></button>
            </div>
            <div class="offcanvas-body admin_sidebar_links">
                <a href="index.php">Dashboard</a>
                <a href="orders.php">Orders</a>
                <a href="products.php">Products</a>
                <a href="arrange-products.php">Arrange Products</a>
                <a href="add-product.php">Add Product</a>
                <a href="variants.php">Variants</a>
                <a href="categories.php">Categories</a>
                <a href="categories-arrange.php">Arrange Categories</a>
                <a href="banners.php">Banners</a>
                <a href="banners-arrange.php">Arrange Banners</a>
                <a href="messages.php">Messages</a>
            </div>
        </aside>

        <section class="admin_layout_main" style="width: 100%">
            <div class="px-3 py-2">