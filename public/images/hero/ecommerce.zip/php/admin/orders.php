<?php
require('connection.php');

// Pagination parameters
$limit = 10; // Number of orders per page
$page = isset($_GET['page']) ? $_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Filter parameters
$status = isset($_GET['status']) ? $_GET['status'] : 'all'; // Default to all orders
$name = isset($_GET['name']) ? $_GET['name'] : ''; // Default to empty
$phoneNumber = isset($_GET['phoneNumber']) ? $_GET['phoneNumber'] : ''; // Default to empty

// Query to fetch orders based on status, name, phone number, and pagination
$sql = "SELECT * FROM orders WHERE 1=1";
$bindParams = ''; // Initialize bindParams string
$bindValues = array(); // Initialize bindValues array

// Add conditions based on filters
if ($status !== 'all') {
    $sql .= " AND (order_status = ?)";
    $bindParams .= 's';
    $bindValues[] = &$status;
}
if (!empty($name)) {
    $sql .= " AND full_name LIKE ?";
    $bindParams .= 's';
    $nameParam = "%$name%";
    $bindValues[] = &$nameParam;
}
if (!empty($phoneNumber)) {
    $sql .= " AND phone_number LIKE ?";
    $bindParams .= 's';
    $phoneNumberParam = "%$phoneNumber%";
    $bindValues[] = &$phoneNumberParam;
}

$sql .= " ORDER BY order_date DESC LIMIT ?, ?";
$bindParams .= 'ii';
$bindValues[] = &$offset;
$bindValues[] = &$limit;

$stmt = mysqli_prepare($con, $sql);
if ($stmt === false) {
    die(mysqli_error($con));
}

// Bind parameters dynamically
if ($bindParams !== '') {
    $bindParams = str_split($bindParams); // Convert string to array
    $bindParams = implode('', array_map(function ($type) {
        return $type === 's' ? 's' : 'i'; // Convert 's' to 's' and other types to 'i'
    }, $bindParams)); // Convert back to string
    array_unshift($bindValues, $bindParams);
    call_user_func_array('mysqli_stmt_bind_param', array_merge(array($stmt), $bindValues));
}

mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

// Fetch orders
$orders = mysqli_fetch_all($result, MYSQLI_ASSOC);

// Total number of orders
$sqlTotal = "SELECT COUNT(*) AS total FROM orders WHERE 1=1";
$bindParamsTotal = ''; // Initialize bindParamsTotal string
$bindValuesTotal = array(); // Initialize bindValuesTotal array

// Add conditions based on filters for total count query
if ($status !== 'all') {
    $sqlTotal .= " AND (order_status = ?)";
    $bindParamsTotal .= 's';
    $bindValuesTotal[] = &$status;
}
if (!empty($name)) {
    $sqlTotal .= " AND full_name LIKE ?";
    $bindParamsTotal .= 's';
    $nameParam = "%$name%";
    $bindValuesTotal[] = &$nameParam;
}
if (!empty($phoneNumber)) {
    $sqlTotal .= " AND phone_number LIKE ?";
    $bindParamsTotal .= 's';
    $phoneNumberParam = "%$phoneNumber%";
    $bindValuesTotal[] = &$phoneNumberParam;
}

$stmtTotal = mysqli_prepare($con, $sqlTotal);
if ($stmtTotal === false) {
    die(mysqli_error($con));
}

// Bind parameters for total count query
if ($bindParamsTotal !== '') {
    $bindParamsTotal = str_split($bindParamsTotal); // Convert string to array
    $bindParamsTotal = implode('', array_map(function ($type) {
        return $type === 's' ? 's' : 'i'; // Convert 's' to 's' and other types to 'i'
    }, $bindParamsTotal)); // Convert back to string
    array_unshift($bindValuesTotal, $bindParamsTotal);
    call_user_func_array('mysqli_stmt_bind_param', array_merge(array($stmtTotal), $bindValuesTotal));
}

mysqli_stmt_execute($stmtTotal);
$resultTotal = mysqli_stmt_get_result($stmtTotal);
$rowTotal = mysqli_fetch_assoc($resultTotal);
$totalOrders = $rowTotal['total'];

// Pagination links
$totalPages = ceil($totalOrders / $limit);
?>

<?php include("./layout.php"); ?>

<section>
    <h3 class="text-center">ORDERS</h3>
    <div class="mt-4">
        <form action="" method="GET" class="d-flex align-items-center gap-2">
            <select id="status" name="status" class="form-control shadow-none" style="max-width: fit-content;">
                <option value="all" <?php if ($status === 'all') echo 'selected'; ?>>All</option>
                <option value="pending" <?php if ($status === 'pending') echo 'selected'; ?>>Pending</option>
                <option value="shipped" <?php if ($status === 'shipped') echo 'selected'; ?>>Shipped</option>
                <option value="delivered" <?php if ($status === 'delivered') echo 'selected'; ?>>Delivered</option>
                <option value="cancelled" <?php if ($status === 'cancelled') echo 'selected'; ?>>Cancelled</option>
            </select>
            <input type="text" class="form-control shadow-none" style="max-width: fit-content;" name="name" placeholder="Name" value="<?php echo $name; ?>">
            <input type="text" class="form-control shadow-none" style="max-width: fit-content;" name="phoneNumber" placeholder="Phone Number" value="<?php echo $phoneNumber; ?>">
            <button type="submit" class="btn btn-outline-dark">Apply Filter</button>
        </form>
    </div>
    <div class="table-responsive mt-3">
        <table class="table table-bordered table-hover">
            <thead>
                <tr>
                    <th class="text-nowrap">Order ID</th>
                    <th></th>
                    <th>Full Name</th>
                    <th class="text-nowrap">Phone Number</th>
                    <th>Province</th>
                    <th>City</th>
                    <th>Order Date</th>
                    <th class="text-nowrap">Total Amount</th>
                    <th class="text-nowrap">Order Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($orders as $order) : ?>
                    <tr>
                        <td><?php echo $order['id']; ?></td>
                        <td><a href="order-detail.php?order_id=<?php echo $order['id']; ?>" class="text-dark">View</a></td>
                        <td class="text-nowrap"><?php echo $order['full_name']; ?></td>
                        <td><?php echo $order['phone_number']; ?></td>
                        <td><?php echo $order['province']; ?></td>
                        <td><?php echo $order['city']; ?></td>
                        <td class="text-nowrap"><?php echo $order['order_date']; ?></td>
                        <td><?php echo $order['total_amount']; ?></td>
                        <td><?php echo $order['order_status']; ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <nav aria-label="Page navigation example">
        <ul class="pagination">
            <li class="page-item <?php echo ($page == 1) ? 'disabled' : ''; ?>">
                <a class="page-link" href="?page=<?php echo ($page - 1); ?>&status=<?php echo $status; ?>&name=<?php echo $name; ?>&phoneNumber=<?php echo $phoneNumber; ?>" aria-label="Previous">
                    <span aria-hidden="true">&laquo;</span>
                </a>
            </li>
            <?php for ($i = 1; $i <= $totalPages; $i++) : ?>
                <li class="page-item <?php echo ($page == $i) ? 'active' : ''; ?>">
                    <a class="page-link" href="?page=<?php echo $i; ?>&status=<?php echo $status; ?>&name=<?php echo $name; ?>&phoneNumber=<?php echo $phoneNumber; ?>"><?php echo $i; ?></a>
                </li>
            <?php endfor; ?>
            <li class="page-item <?php echo ($page == $totalPages) ? 'disabled' : ''; ?>">
                <a class="page-link" href="?page=<?php echo ($page + 1); ?>&status=<?php echo $status; ?>&name=<?php echo $name; ?>&phoneNumber=<?php echo $phoneNumber; ?>" aria-label="Next">
                    <span aria-hidden="true">&raquo;</span>
                </a>
            </li>
        </ul>
    </nav>

</section>

<?php include("./layout-end.php"); ?>