<?php
require('../connection.php');

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["banner_id"])) {
    $bannerId = $_POST["banner_id"];
    echo "Banner ID: $bannerId";

    // Fetch banner information to get image paths
    $sql_select = "SELECT desktop_image_path, mobile_image_path FROM banners WHERE id = ?";
    $stmt_select = mysqli_prepare($con, $sql_select);

    if ($stmt_select) {
        mysqli_stmt_bind_param($stmt_select, "i", $bannerId);
        mysqli_stmt_execute($stmt_select);
        mysqli_stmt_store_result($stmt_select);

        if (mysqli_stmt_num_rows($stmt_select) > 0) {
            mysqli_stmt_bind_result($stmt_select, $desktopImagePath, $mobileImagePath);
            mysqli_stmt_fetch($stmt_select);

            // Delete banner record from the database
            $sql_delete = "DELETE FROM banners WHERE id = ?";
            $stmt_delete = mysqli_prepare($con, $sql_delete);

            if ($stmt_delete) {
                mysqli_stmt_bind_param($stmt_delete, "i", $bannerId);

                if (mysqli_stmt_execute($stmt_delete)) {
                    // Delete desktop image
                    if (unlink($desktopImagePath)) {
                        // Desktop image deleted successfully
                    } else {
                        // Error deleting desktop image
                        echo "Error deleting desktop image";
                    }

                    // Delete mobile image
                    if (unlink($mobileImagePath)) {
                        // Mobile image deleted successfully
                    } else {
                        // Error deleting mobile image
                        echo "Error deleting mobile image";
                    }

                    echo "Banner deleted successfully.";
                } else {
                    // Error deleting banner record
                    echo "Error deleting banner record: " . mysqli_error($con);
                }

                mysqli_stmt_close($stmt_delete);
            } else {
                // Error preparing delete statement for banner record
                echo "Error preparing delete statement for banner record: " . mysqli_error($con);
            }
        } else {
            // Banner not found
            echo "Banner not found.";
        }

        mysqli_stmt_close($stmt_select);
    } else {
        // Error preparing select statement
        echo "Error preparing select statement: " . mysqli_error($con);
    }
} else {
    // Invalid request or missing parameters
    echo "Invalid request";
}

// Close connection
mysqli_close($con);
