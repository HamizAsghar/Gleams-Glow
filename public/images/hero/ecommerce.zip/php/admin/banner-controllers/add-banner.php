<?php
require('../connection.php');

if (isset($_POST['submit'])) {
    // Check if all input fields are filled
    if (!empty($_FILES['desktop_image']['name']) && !empty($_FILES['mobile_image']['name']) && !empty($_POST['link'])) {
        // Define upload directory
        $uploadDir = '../../assets/uploads/';

        // Upload desktop image
        $desktopImagePath = uploadImage($_FILES['desktop_image'], $uploadDir);

        // Upload mobile image
        $mobileImagePath = uploadImage($_FILES['mobile_image'], $uploadDir);

        // Get other form data
        $link = $_POST['link'];

        // Save the image details to MySQL if images were successfully uploaded
        if ($desktopImagePath && $mobileImagePath) {
            $sql = "INSERT INTO banners (desktop_image_path, mobile_image_path, link) VALUES ('$desktopImagePath', '$mobileImagePath', '$link')";
            if (mysqli_query($con, $sql)) {
                header("Location: ../banners.php");
                exit();
            } else {
                echo "Error: " . $sql . "<br>" . mysqli_error($con);
            }
        } else {
            echo "Failed to upload images.";
        }
    } else {
        echo "All input fields are required.";
    }
}

function uploadImage($file, $uploadDir)
{
    $filename = uniqid() . '_' . basename($file['name']);
    $targetFilePath = $uploadDir . $filename;

    if (move_uploaded_file($file['tmp_name'], $targetFilePath)) {
        return $targetFilePath;
    }
    return false;
}
