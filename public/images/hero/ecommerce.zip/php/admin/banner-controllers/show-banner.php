<?php
require('connection.php');

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['updateTextForm'])) {
    $bannerId = $_POST['bannerId'];
    $bannerText = $_POST['bannerText'];

    $sql = "UPDATE banners SET link = '$bannerText' WHERE id = $bannerId";
    mysqli_query($con, $sql);

    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

?>

<section class="my-3">
    <h4 class="">All Banners:</h4>
    <div class="mt-3 d-flex flex-column gap-3">
        <?php
        $sql = "SELECT * FROM banners";
        $result = mysqli_query($con, $sql);

        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                echo '<div class="d-flex admin_banner_container" data-banner-id="' . $row['id'] . '" style="border: 1px solid silver; border-radius: 10px;">
    <div class="p-2 d-flex flex-wrap gap-3 justify-content-evenly flex-grow-1">
        <div>
            <div class="fw-bold" style="color: gray;">Link:</div>
            <div class="fw-bold banner-link d-flex flex-column" data-banner-id="' . $row['id'] . '">
                <span class="editable" contenteditable="true">' . htmlspecialchars($row['link']) . '</span>
                <button class="btn btn-outline-dark btn-sm update-link-btn mt-2">Update</button>
            </div>
        </div>
        <div>
            <div class="fw-bold" style="color: gray;">Desktop Image:</div>
            <div class="pt-1" style="max-width: 250px;"><img style="border-radius: 5px;" src="../assets/uploads/' . basename($row['desktop_image_path']) . '" width="100%" alt="Banner"></div>
        </div>
        <div>
            <div class="fw-bold" style="color: gray;">Mobile Image:</div>
            <div class="pt-1" style="max-width: 250px;"><img style="border-radius: 5px;" src="../assets/uploads/' . basename($row['mobile_image_path']) . '" width="100%" alt="Banner"></div>
        </div>
    </div>

    <button type="button" class="admin_banner_del_btn fw-bold text-center p-2 border-0 outline-0" style="writing-mode: tb; transform: rotate(-180deg); border-bottom-left-radius: 9px; border-top-left-radius: 10px;">DELETE</button>
    
</div>';
            }
        } else {
            echo '<div class="d-flex justify-content-center align-items-center">No banners available.</div>';
        }
        ?>
    </div>
</section>

<script>
    document.querySelectorAll('.update-link-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            var bannerId = this.parentElement.dataset.bannerId;
            var newLink = this.parentElement.querySelector('.editable').innerText;

            // AJAX request to update the link
            var xhr = new XMLHttpRequest();
            xhr.open('POST', '<?php echo $_SERVER['PHP_SELF']; ?>', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.onreadystatechange = function() {
                if (xhr.readyState === XMLHttpRequest.DONE) {
                    if (xhr.status === 200) {
                        // Update successful, you might want to show a success message or update the UI
                        console.log('Link updated successfully');
                    } else {
                        // Update failed, handle error
                        console.error('Failed to update link');
                    }
                }
            };
            xhr.send('updateTextForm=true&bannerId=' + encodeURIComponent(bannerId) + '&bannerText=' + encodeURIComponent(newLink));
        });
    });
</script>