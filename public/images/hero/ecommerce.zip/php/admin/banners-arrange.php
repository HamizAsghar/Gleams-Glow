<?php include("./layout.php"); ?>
<?php
require('connection.php');
?>

<section>
    <h3 class="text-center">ARRANGE BANNERS</h3>
    <section class="table-responsive">
        <table class="table table-striped table-hover">
            <?php
            $sql = "SELECT id, desktop_image_path, mobile_image_path, link, arrange FROM banners ORDER BY arrange ASC";
            $result = mysqli_query($con, $sql);

            if (mysqli_num_rows($result) > 0) {
                echo '<tr>
            <th style="vertical-align: middle;">#</th>
            <th style="vertical-align: middle;">Order</th>
            <th style="vertical-align: middle;">Desktop Image</th>
            <th style="vertical-align: middle;">Mobile Image</th>
            <th style="text-align: center; vertical-align: middle;">Link</th>
        </tr>';
                $index = 1;
                while ($row = mysqli_fetch_assoc($result)) {
                    echo '
            <tr class="banner w-100" style="min-width: 100%" draggable="true" data-banner-id="' . $row['id'] . '">
                <td style="vertical-align: middle;">' . $index++ . '</td>
                <td style="text-align: center; vertical-align: middle;">' . $row['arrange'] . '</td>
                <td style="vertical-align: middle;">
                    <img style="object-fit: cover; width: 100px; aspect-ratio: auto;" src="../assets/uploads/' . basename($row['desktop_image_path']) . '" alt="banner">
                </td>
                <td style="vertical-align: middle;">
                    <img style="object-fit: cover; width: 100px; aspect-ratio: auto;" src="../assets/uploads/' . basename($row['mobile_image_path']) . '" alt="banner">
                </td>
                <td style="text-align: center; vertical-align: middle;">' . $row['link'] . '</td>
            </tr>
            ';
                }
            } else {
                echo '<div class="d-flex justify-content-center align-items-center">No views today.</div>';
            }
            ?>
        </table>
    </section>
    <div class="text-center">
        <button type="button" class="save_button btn btn-dark px-4 rounded-5">SAVE</button>
    </div>
</section>

<script>
    const banners = document.querySelectorAll('.banner');
    let draggedItem = null;
    banners.forEach(banner => {
        banner.addEventListener('dragstart', dragStart);
        banner.addEventListener('dragend', dragEnd);
        banner.addEventListener('dragover', dragOver);
        banner.addEventListener('dragenter', dragEnter);
        banner.addEventListener('dragleave', dragLeave);
        banner.addEventListener('drop', dragDrop);
    });

    function dragStart() {
        draggedItem = this;
        setTimeout(() => {
            this.style.display = 'none';
        }, 0);
    }

    function dragEnd() {
        setTimeout(() => {
            draggedItem.style.display = '';
            draggedItem = null;
        }, 0);
    }

    function dragOver(e) {
        e.preventDefault();
    }

    function dragEnter(e) {
        e.preventDefault();
        this.style.backgroundColor = 'rgba(0, 0, 0, 0.1)';
    }

    function dragLeave() {
        this.style.backgroundColor = 'transparent';
    }

    function dragDrop() {
        this.style.backgroundColor = 'transparent';
        this.parentNode.insertBefore(draggedItem, this);
    }

    document.querySelector('.save_button').addEventListener('click', function() {
        const banners = document.querySelectorAll('.banner');
        const bannerIds = Array.from(banners).map(banner => banner.dataset.bannerId);
        const newArrangeValues = Array.from(banners).map((banner, index) => ({
            id: banner.dataset.bannerId,
            arrange: index + 1 // Assign new arrange values based on the new order
        }));

        // Send the new arrangement data to the server via AJAX
        fetch('banner-controllers/arrange-banner.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(newArrangeValues)
            })
            .then(response => {
                if (response.ok) {
                    alert('Banner arrangement saved successfully.');
                } else {
                    throw new Error('Failed to save banner arrangement.');
                }
            })
            .catch(error => {
                console.error('Error saving banner arrangement:', error);
                alert('Failed to save banner arrangement. Please try again.');
            });
    });
</script>

<?php include("./layout-end.php"); ?>