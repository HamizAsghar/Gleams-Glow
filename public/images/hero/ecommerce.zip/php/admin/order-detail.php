<?php
include("./layout.php");
require('connection.php');

// Handle order status update if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["update_status"])) {
    $order_id = $_POST["order_id"];
    $new_status = $_POST["status"];

    // Update order status in the database
    $update_query = "UPDATE orders SET order_status = '$new_status' WHERE id = $order_id";
    mysqli_query($con, $update_query);
}

// Fetch order details
$order_id = $_GET['order_id']; // Assuming you're passing order_id in the URL
$order_query = "SELECT * FROM orders WHERE id = $order_id";
$order_result = mysqli_query($con, $order_query);
$order = mysqli_fetch_assoc($order_result);

// Fetch order items
$order_items_query = "SELECT * FROM order_items WHERE order_id = $order_id";
$order_items_result = mysqli_query($con, $order_items_query);

// Order status options
$status_options = ['pending', 'shipped', 'delivered', 'cancelled'];

?>
<section>
    <h3 class="text-center">ORDER - <?php echo $order_id; ?></h3>
    <div class="order-details">
        <p><strong>Full Name:</strong> <?php echo $order['full_name']; ?></p>
        <p><strong>Email:</strong> <?php echo $order['email']; ?></p>
        <p><strong>Phone Number:</strong> <?php echo $order['phone_number']; ?></p>
        <p><strong>Address:</strong> <?php echo $order['address']; ?></p>
        <p><strong>Country:</strong> <?php echo $order['country']; ?></p>
        <p><strong>Province:</strong> <?php echo $order['province']; ?></p>
        <p><strong>City:</strong> <?php echo $order['city']; ?></p>
        <p><strong>ZIP:</strong> <?php echo $order['zip']; ?></p>
        <p><strong>Message:</strong> <?php echo $order['message']; ?></p>
        <p><strong>Order Date:</strong> <?php echo $order['order_date']; ?></p>
        <p><strong>Total Amount:</strong> <?php echo $order['total_amount']; ?></p>
        <form method="POST" class="d-flex align-items-center gap-2">
            <input type="hidden" name="order_id" value="<?php echo $order_id; ?>">
            <label for="status"><strong>Order Status:</strong></label>
            <select name="status" id="status" class="form-control" style="max-width: fit-content;">
                <?php foreach ($status_options as $status) : ?>
                    <option value="<?php echo $status; ?>" <?php echo ($order['order_status'] == $status) ? 'selected' : ''; ?>><?php echo ucfirst($status); ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit" name="update_status" class="btn btn-outline-success">Update Status</button>
        </form>
    </div>
    <div class="order-items mt-3">
        <h4>Order Items:</h4>
        <ul>
            <?php while ($order_item = mysqli_fetch_assoc($order_items_result)) : ?>
                <li class="my-1">
                    <a href="product.php?product=<?php echo $order_item['product_id']; ?>" class="text-dark text-decoration-none fw-medium"><?php echo $order_item['product_title']; ?></a>
                    <div>Price <strong class="text-primary"><?php echo $order_item['price_per_item']; ?></strong> x Quantity <strong class="text-primary"><?php echo $order_item['quantity']; ?></strong> = Final Price <strong class="text-primary"><?php echo $order_item['price_per_item'] * $order_item['quantity']; ?></strong></div>
                </li>
            <?php endwhile; ?>
        </ul>
    </div>
</section>
<?php include("./layout-end.php"); ?>