<?php
require('connection.php');
include("./layout.php");
?>

<section>
    <h3 class="text-center">VARIANTS</h3>

    <!-- Form to add new variant -->
    <h4 class="mt-4">Add New Variant:</h4>
    <form method="post" class="add_product_form mt-2" action="variant-controllers/add-variant.php">
        <div class="form-group">
            <label for="variantName">Variant Name:</label>
            <input type="text" id="variantName" name="variantName" class="form-control shadow-none" placeholder="Enter variant name" required>
        </div>
        <div class="form-group">
            <label for="variantType">Variant Type:</label>
            <select id="variantType" name="variantType" class="form-control shadow-none" required>
                <option value="">Select variant type</option>
                <option value="color">Color</option>
                <option value="size">Size</option>
            </select>
        </div>
        <button type="submit" class="btn btn-dark">Add Variant</button>
    </form>

    <!-- Display existing variants -->
    <h4 class="mt-4">Existing Variants:</h4>
    <div class="mt-2" style="border: 1px solid silver; padding: 20px; width: 100%; border-radius: 10px;">
        <div>
            <h5 class="mb-2">Colors:</h5>
            <?php

            $sql = "SELECT * FROM variants WHERE type='color'";
            $result = mysqli_query($con, $sql);

            if (mysqli_num_rows($result) > 0) {
                echo "<div class='existing_variants mt-2'>";
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<div>
            <div>{$row['name']}</div> 
            <div><form action='variant-controllers/delete-variant.php' method='POST'>
            <input type='hidden' name='variant_id' value='{$row['id']}'>
                <button type='submit' class='btn p-0'><svg aria-hidden='true' xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='none' viewBox='0 0 24 24'>
                <path stroke='currentColor' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M5 7h14m-9 3v8m4-8v8M10 3h4a1 1 0 0 1 1 1v3H9V4a1 1 0 0 1 1-1ZM6 7h12v13a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V7Z'/>
            </svg></button>
        </form></div>
        </div>";
                }
                echo "</div>";
            } else {
                echo "No variants found.";
            }
            ?>
        </div>
        <div class="mt-3">
            <h5 class="mb-2">Sizes:</h5>
            <?php

            $sql = "SELECT * FROM variants WHERE type='size'";
            $result = mysqli_query($con, $sql);

            if (mysqli_num_rows($result) > 0) {
                echo "<div class='existing_variants mt-2'>";
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<div>
            <div>{$row['name']}</div> 
            <div><form action='variant-controllers/delete-variant.php' method='POST'>
            <input type='hidden' name='variant_id' value='{$row['id']}'>
                <button type='submit' class='btn p-0'><svg aria-hidden='true' xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='none' viewBox='0 0 24 24'>
                <path stroke='currentColor' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M5 7h14m-9 3v8m4-8v8M10 3h4a1 1 0 0 1 1 1v3H9V4a1 1 0 0 1 1-1ZM6 7h12v13a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V7Z'/>
            </svg></button>
        </form></div>
        </div>";
                }
                echo "</div>";
            } else {
                echo "No variants found.";
            }
            ?>
        </div>
    </div>
</section>

<?php include("./layout-end.php"); ?>