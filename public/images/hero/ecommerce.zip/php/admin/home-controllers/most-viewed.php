<section class="table-responsive">
    <h4 class="mt-3">Most Viewed Products Today:</h4>
    <table class="table table-striped table-hover">

        <?php
        $currentDate = date("Y-m-d");
        $sql = "SELECT id, thumbnail_image, title, slug, home_page, best_selling, arrange, views, date_view FROM products WHERE views > 0 AND date_view = '$currentDate' ORDER BY views DESC";
        $result = mysqli_query($con, $sql);

        if (mysqli_num_rows($result) > 0) {
            echo '<tr>
            <th style="vertical-align: middle;">#</th>
            <th style="vertical-align: middle;">Image</th>
            <th style="vertical-align: middle;">Title</th>
            <th style="text-align: center; vertical-align: middle;">Arrange</th>
            <th style="text-align: center; vertical-align: middle;">Views</th>
            <th class="text-nowrap" style="text-align: center; vertical-align: middle;">Best Selling</th>
            <th class="text-nowrap" style="text-align: center; vertical-align: middle;">Home Page</th>
        </tr>';
            $index = 1;
            while ($row = mysqli_fetch_assoc($result)) {
                echo '
            <tr>
                <td style="vertical-align: middle;">' . $index++ . '</td>
                <td style="vertical-align: middle;">
                    <a href="product.php?product=' . $row['slug'] . '">
                        <img style="border-radius: 50%;object-fit: cover;" src="../assets/uploads/thumbnails/' . basename($row['thumbnail_image']) . '" width="50px" height="50px" alt="Product">
                    </a>
                </td>
                <td style="vertical-align: middle;min-width: 250px;">
                    <a href="product.php?product=' . $row['slug'] . '" style="text-decoration: none; color: black;">
                    ' . $row['title'] . '
                    </a>
                </td>
                <td style="text-align: center; vertical-align: middle;">' . $row['arrange'] . '</td>
                <td style="text-align: center; vertical-align: middle;">' . $row['views'] . '</td>
                <td style="text-align: center; vertical-align: middle; text-transform: capitalize;">' . $row['best_selling'] . '</td>
                <td style="text-align: center; vertical-align: middle; text-transform: capitalize;">' . $row['home_page'] . '</td>
            </tr>
            ';
            }
        } else {
            echo '<div class="d-flex justify-content-center align-items-center">No views today.</div>';
        }
        ?>
    </table>
</section>