<?php
require('connection.php');
include("./layout.php");

$recordsPerPage = 15;

$page = isset($_GET['page']) && is_numeric($_GET['page']) ? $_GET['page'] : 1;

$offset = ($page - 1) * $recordsPerPage;

$sql = "SELECT id, thumbnail_image, title, slug, price, discounted_price, home_page, best_selling, arrange FROM products LIMIT ?, ?";
$stmt = mysqli_prepare($con, $sql);
mysqli_stmt_bind_param($stmt, "ii", $offset, $recordsPerPage);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

?>
<section>
    <h3 class="text-center">ALL PRODUCTS</h3>
    <section class="table-responsive">
        <table class="table table-striped table-hover">
            <tr>
                <th style="vertical-align: middle;">#</th>
                <th style="vertical-align: middle;">Image</th>
                <th style="vertical-align: middle;">Title</th>
                <th style="text-align: center; vertical-align: middle;">Price</th>
                <th style="text-align: center; vertical-align: middle;">Arrange</th>
                <th style="text-align: center; vertical-align: middle;">Best Selling</th>
                <th style="text-align: center; vertical-align: middle;">Home Page</th>
            </tr>
            <?php
            if (mysqli_num_rows($result) > 0) {
                $index = ($page - 1) * $recordsPerPage + 1;
                while ($row = mysqli_fetch_assoc($result)) {
                    echo '
                <tr>
                    <td style="vertical-align: middle;">' . $index++ . '</td>
                    <td style="vertical-align: middle;">
                        <a href="product.php?product=' . $row['slug'] . '">
                            <img style="border-radius: 50%;object-fit: cover;" src="../assets/uploads/thumbnails/' . basename($row['thumbnail_image']) . '" width="50px" height="50px" alt="Product">
                        </a>
                    </td>
                    <td style="vertical-align: middle;">
                        <a href="product.php?product=' . $row['slug'] . '" style="text-decoration: none; color: black;">
                        ' . $row['title'] . '
                        </a>
                    </td>
                    <td style="text-align: center; vertical-align: middle;">Rs. ' . ($row['discounted_price'] > 0 ? number_format($row['discounted_price'], 0) : number_format($row['price'], 0)) . '</td>
                    <td style="text-align: center; vertical-align: middle;">' . $row['arrange'] . '</td>
                    <td style="text-align: center; vertical-align: middle; text-transform: capitalize;">' . $row['best_selling'] . '</td>
                    <td style="text-align: center; vertical-align: middle; text-transform: capitalize;">' . $row['home_page'] . '</td>
                </tr>';
                }
            } else {
                echo '<tr><td colspan="7" class="text-center">No records found.</td></tr>';
            }
            ?>
        </table>
        <?php
        $sql = "SELECT COUNT(*) AS total FROM products";
        $result = mysqli_query($con, $sql);
        $row = mysqli_fetch_assoc($result);
        $totalPages = ceil($row['total'] / $recordsPerPage);

        echo '<ul class="pagination justify-content-center">';
        for ($i = 1; $i <= $totalPages; $i++) {
            $active = $i == $page ? 'active' : '';
            echo '<li class="page-item ' . $active . '"><a class="page-link" href="?page=' . $i . '">' . $i . '</a></li>';
        }
        echo '</ul>';
        ?>
    </section>
</section>

<?php include("./layout-end.php"); ?>