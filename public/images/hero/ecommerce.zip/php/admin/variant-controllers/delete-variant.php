<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if variant ID and type are provided
    if (isset($_POST['variant_id'])) {
        $variantId = $_POST['variant_id'];

        // Include your database connection
        require('../connection.php');

        // Start a transaction
        mysqli_autocommit($con, false);

        // Delete associated entries from the product_variants table
        $deleteProductVariantQuery = "DELETE FROM product_variants WHERE variant_id = ?";
        $deleteProductVariantStatement = mysqli_prepare($con, $deleteProductVariantQuery);
        mysqli_stmt_bind_param($deleteProductVariantStatement, "i", $variantId);
        mysqli_stmt_execute($deleteProductVariantStatement);

        // Delete the variant from the variants table
        $deleteVariantQuery = "DELETE FROM variants WHERE id = ?";
        $deleteVariantStatement = mysqli_prepare($con, $deleteVariantQuery);
        mysqli_stmt_bind_param($deleteVariantStatement, "i", $variantId);
        mysqli_stmt_execute($deleteVariantStatement);

        // Commit the transaction
        mysqli_commit($con);

        // Check if any rows were affected
        if (mysqli_stmt_affected_rows($deleteVariantStatement) > 0) {
            // Variant deleted successfully
            echo json_encode(['success' => true]);
        } else {
            // Variant not found or deletion failed
            echo json_encode(['success' => false, 'message' => 'Variant not found or deletion failed.']);
        }

        // Close statements and database connection
        mysqli_stmt_close($deleteVariantStatement);
        mysqli_stmt_close($deleteProductVariantStatement);
        mysqli_close($con);
        header('Location: ../variants.php');
    } else {
        // Variant ID or type not provided
        echo json_encode(['success' => false, 'message' => 'Variant ID or type not provided.']);
    }
} else {
    // If the request method is not POST, return an error response
    http_response_code(405); // Method Not Allowed
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
}
