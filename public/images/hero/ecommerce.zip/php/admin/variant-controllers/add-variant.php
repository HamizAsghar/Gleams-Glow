<?php
require('../connection.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $variantName = $_POST['variantName'];
    $variantType = $_POST['variantType'];

    $sql = "INSERT INTO variants (name, type) VALUES (?, ?)";
    $stmt = mysqli_prepare($con, $sql);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "ss", $variantName, $variantType);
        mysqli_stmt_execute($stmt);

        if (mysqli_stmt_affected_rows($stmt) > 0) {
            mysqli_stmt_close($stmt);
            mysqli_close($con);

            header("Location: ../variants.php");
            exit();
        } else {
            echo "Failed to add new variant.";
        }

        mysqli_stmt_close($stmt);
    } else {
        echo "Error: " . mysqli_error($con);
    }

    mysqli_close($con);
}
