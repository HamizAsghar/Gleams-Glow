<?php
require('../connection.php');

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['updateTitleForm'])) {
    $productId = $_POST['productId'];
    $newTitle = $_POST['newTitle'];

    // Generate a new slug based on the new title
    $newSlug = generateUniqueSlug($newTitle, $con);

    $sql = "UPDATE products SET title = ?, slug = ? WHERE id = ?";
    $stmt = mysqli_prepare($con, $sql);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "ssi", $newTitle, $newSlug, $productId);
        if (mysqli_stmt_execute($stmt)) {
            mysqli_stmt_close($stmt);
            header("Location: ../product.php?product=$newSlug");
            exit();
        } else {
            echo "Error updating title: " . mysqli_error($con);
        }
    } else {
        echo "Error preparing SQL statement: " . mysqli_error($con);
    }
} else {
    header("Location: ../404.php");
    exit();
}

function generateUniqueSlug($title, $connection)
{
    // Convert title to lowercase
    $slug = strtolower($title);

    // Replace spaces with hyphens
    $slug = str_replace(' ', '-', $slug);

    // Remove special characters
    $slug = preg_replace('/[^A-Za-z0-9\-]/', '', $slug);

    // Check if slug already exists in the database
    $query = "SELECT COUNT(*) AS count FROM products WHERE slug = '$slug'";
    $result = mysqli_query($connection, $query);
    $row = mysqli_fetch_assoc($result);
    $count = $row['count'];

    // If slug already exists, append a unique identifier
    if ($count > 0) {
        $unique_identifier = 1;
        while ($count > 0) {
            $new_slug = $slug . '-' . $unique_identifier;
            $query = "SELECT COUNT(*) AS count FROM products WHERE slug = '$new_slug'";
            $result = mysqli_query($connection, $query);
            $row = mysqli_fetch_assoc($result);
            $count = $row['count'];
            $unique_identifier++;
        }
        $slug = $new_slug;
    }

    return $slug;
}
