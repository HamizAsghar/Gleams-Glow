<?php
require('../connection.php');

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["productId"]) && isset($_POST["variantId"])) {
    // Get product ID and variant ID from the form
    $productId = $_POST["productId"];
    $variantId = $_POST["variantId"];

    // Insert new variant into product_variants table
    $sql = "INSERT INTO product_variants (product_id, variant_id) VALUES (?, ?)";
    $stmt = mysqli_prepare($con, $sql);

    // Bind parameters and execute the statement
    mysqli_stmt_bind_param($stmt, "ii", $productId, $variantId);

    if (mysqli_stmt_execute($stmt)) {
        // Variant added successfully
        $slug = getSlug($productId, $con);
        header("Location: ../product.php?product=$slug");
        exit();
    } else {
        // Error adding variant
        echo "Error: " . mysqli_error($con);
    }

    // Close statement
    mysqli_stmt_close($stmt);
}

// Function to get slug based on product ID
function getSlug($productId, $connection)
{
    $sql = "SELECT slug FROM products WHERE id = ?";
    $stmt = mysqli_prepare($connection, $sql);

    // Bind parameter and execute the statement
    mysqli_stmt_bind_param($stmt, "i", $productId);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $slug);
    mysqli_stmt_fetch($stmt);

    // Close statement
    mysqli_stmt_close($stmt);

    return $slug;
}
