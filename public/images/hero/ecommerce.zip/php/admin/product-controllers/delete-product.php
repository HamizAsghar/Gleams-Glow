<?php
require('../connection.php');

// Function to delete an image file from the server
function deleteImage($imagePath)
{
    if (file_exists($imagePath)) {
        unlink($imagePath);
        return true; // Image deleted successfully
    } else {
        return false; // Image does not exist or unable to delete
    }
}

// Check if product ID is provided
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["productId"])) {
    // Get the product ID
    $productId = $_POST["productId"];

    $deleteCartItemsQuery = "DELETE FROM cart WHERE product_id = ?";
    $stmtDeleteCartItems = mysqli_prepare($con, $deleteCartItemsQuery);
    mysqli_stmt_bind_param($stmtDeleteCartItems, "i", $productId);
    mysqli_stmt_execute($stmtDeleteCartItems);
    mysqli_stmt_close($stmtDeleteCartItems);

    // Delete thumbnail image from the "thumbnails" folder
    $sqlSelectThumbnail = "SELECT thumbnail_image FROM products WHERE id = ?";
    $stmtSelectThumbnail = mysqli_prepare($con, $sqlSelectThumbnail);
    mysqli_stmt_bind_param($stmtSelectThumbnail, "i", $productId);
    mysqli_stmt_execute($stmtSelectThumbnail);
    mysqli_stmt_bind_result($stmtSelectThumbnail, $thumbnailName);
    mysqli_stmt_fetch($stmtSelectThumbnail);
    mysqli_stmt_close($stmtSelectThumbnail);

    $thumbnailPath = "../../assets/uploads/thumbnails/" . $thumbnailName;
    $thumbnailDeleted = deleteImage($thumbnailPath);

    // Delete product images from the "product_images" folder and database
    $sqlSelectImages = "SELECT image_path FROM product_images WHERE product_id = ?";
    $stmtSelectImages = mysqli_prepare($con, $sqlSelectImages);
    mysqli_stmt_bind_param($stmtSelectImages, "i", $productId);
    mysqli_stmt_execute($stmtSelectImages);
    mysqli_stmt_bind_result($stmtSelectImages, $imageName);

    while (mysqli_stmt_fetch($stmtSelectImages)) {
        $imagePath = "../../assets/uploads/product_images/" . $imageName;
        $imageDeleted = deleteImage($imagePath);
    }
    mysqli_stmt_close($stmtSelectImages);

    // Delete images from the database
    $sqlDeleteImages = "DELETE FROM product_images WHERE product_id = ?";
    $stmtDeleteImages = mysqli_prepare($con, $sqlDeleteImages);
    mysqli_stmt_bind_param($stmtDeleteImages, "i", $productId);
    mysqli_stmt_execute($stmtDeleteImages);
    mysqli_stmt_close($stmtDeleteImages);

    // Delete from product_categories table
    $sqlDeleteCategories = "DELETE FROM product_categories WHERE product_id = ?";
    $stmtDeleteCategories = mysqli_prepare($con, $sqlDeleteCategories);
    mysqli_stmt_bind_param($stmtDeleteCategories, "i", $productId);
    mysqli_stmt_execute($stmtDeleteCategories);
    mysqli_stmt_close($stmtDeleteCategories);

    // Delete from product_variants table
    $sqlDeleteVariants = "DELETE FROM product_variants WHERE product_id = ?";
    $stmtDeleteVariants = mysqli_prepare($con, $sqlDeleteVariants);
    mysqli_stmt_bind_param($stmtDeleteVariants, "i", $productId);
    mysqli_stmt_execute($stmtDeleteVariants);
    mysqli_stmt_close($stmtDeleteVariants);

    // Delete from products table
    $sqlDeleteProduct = "DELETE FROM products WHERE id = ?";
    $stmtDeleteProduct = mysqli_prepare($con, $sqlDeleteProduct);
    mysqli_stmt_bind_param($stmtDeleteProduct, "i", $productId);
    mysqli_stmt_execute($stmtDeleteProduct);
    mysqli_stmt_close($stmtDeleteProduct);

    // Redirect back to the product listing page after deletion
    header("Location: ../products.php");
    exit();
} else {
    // Invalid request
    echo "Invalid request";
}

// Close connection
mysqli_close($con);
