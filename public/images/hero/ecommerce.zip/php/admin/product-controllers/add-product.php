<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include_once "../connection.php";

    $unique_id = uniqid();

    // Handle Thumbnail Image upload
    $thumbnail_image = $unique_id . '_' . $_FILES['thumbnail_image']['name'];
    $thumbnail_temp = $_FILES['thumbnail_image']['tmp_name'];
    move_uploaded_file($thumbnail_temp, "../../assets/uploads/thumbnails/$thumbnail_image");

    // Handle Product Images upload
    $product_images = $_FILES['product_images'];
    $product_image_names = array();
    foreach ($product_images['tmp_name'] as $key => $tmp_name) {
        $product_image_name = $unique_id . '_' . $product_images['name'][$key];
        $product_image_names[] = $product_image_name;
        move_uploaded_file($tmp_name, "../../assets/uploads/product_images/$product_image_name");
    }

    // Extract other form fields
    $title = $_POST['title'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $discounted_price = $_POST['discounted_price'];
    $discounted_percentage = $_POST['discounted_percentage'];
    $pieces = isset($_POST['pieces']) ? $_POST['pieces'] : NULL;
    $type = isset($_POST['type']) ? mysqli_real_escape_string($con, $_POST['type']) : NULL;
    $home_page = isset($_POST['home_page']) ? true : false; // Convert to boolean
    $best_selling = isset($_POST['best_selling']) ? true : false; // Convert to boolean

    // Escape string variables
    $title = mysqli_real_escape_string($con, $title);
    $description = mysqli_real_escape_string($con, $description);
    $home_page = mysqli_real_escape_string($con, $home_page);
    $best_selling = mysqli_real_escape_string($con, $best_selling);

    $slug = generateUniqueSlug($title, $con);

    // Insert data into products table
    $insert_product_query = "INSERT INTO products (thumbnail_image, title, slug, description, price, discounted_price, discounted_percentage, pieces, type, home_page, best_selling) 
                            VALUES ('$thumbnail_image', '$title', '$slug', '$description', $price, $discounted_price, $discounted_percentage, $pieces, '$type', '$home_page', '$best_selling')";
    echo $insert_product_query;
    if (mysqli_query($con, $insert_product_query)) {
        $product_id = mysqli_insert_id($con);

        // Handle categories
        $categories = $_POST['categories'];
        foreach ($categories as $category_id) {
            $insert_product_category_query = "INSERT INTO product_categories (product_id, category_id) VALUES ($product_id, $category_id)";
            mysqli_query($con, $insert_product_category_query);
        }

        // Insert product images into database
        foreach ($product_image_names as $product_image_name) {
            $insert_image_query = "INSERT INTO product_images (product_id, image_path) VALUES ($product_id, '$product_image_name')";
            mysqli_query($con, $insert_image_query);
        }

        // Redirect to success page
        header("Location: ../products.php");
        exit();
    } else {
        echo "Error: " . $insert_product_query . "<br>" . mysqli_error($con);
    }

    // Close connection
    mysqli_close($con);
} else {
    // If the form is not submitted, redirect the user to the form page
    header("Location: ../add-product.php");
    exit();
}


function generateUniqueSlug($title, $connection)
{
    // Convert title to lowercase
    $slug = strtolower($title);

    // Replace spaces with hyphens
    $slug = str_replace(' ', '-', $slug);

    // Remove special characters
    $slug = preg_replace('/[^A-Za-z0-9\-]/', '', $slug);

    // Check if slug already exists in the database
    $query = "SELECT COUNT(*) AS count FROM products WHERE slug = '$slug'";
    $result = mysqli_query($connection, $query);
    $row = mysqli_fetch_assoc($result);
    $count = $row['count'];

    // If slug already exists, append a unique identifier
    if ($count > 0) {
        $unique_identifier = 1;
        while ($count > 0) {
            $new_slug = $slug . '-' . $unique_identifier;
            $query = "SELECT COUNT(*) AS count FROM products WHERE slug = '$new_slug'";
            $result = mysqli_query($connection, $query);
            $row = mysqli_fetch_assoc($result);
            $count = $row['count'];
            $unique_identifier++;
        }
        $slug = $new_slug;
    }

    return $slug;
}
