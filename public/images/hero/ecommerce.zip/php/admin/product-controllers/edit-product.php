<?php
require('../connection.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate incoming data
    $productId = $_POST['productId'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $discountedPrice = $_POST['discounted_price'];
    $discountedPercentage = $_POST['discounted_percentage'];
    $pieces = $_POST['pieces'];
    $type = $_POST['type'];
    $homePage = isset($_POST['home_page']) ? true : false; // Convert to boolean
    $bestSelling = isset($_POST['best_selling']) ? true : false; // Convert to boolean

    // Update product in the database
    $updateProductSql = "UPDATE products SET description = ?, price = ?, discounted_price = ?, discounted_percentage = ?, pieces = ?, type = ?, home_page = ?, best_selling = ? WHERE id = ?";
    $stmt = mysqli_prepare($con, $updateProductSql);
    mysqli_stmt_bind_param($stmt, "sdddddddi", $description, $price, $discountedPrice, $discountedPercentage, $pieces, $type, $homePage, $bestSelling, $productId);

    if (mysqli_stmt_execute($stmt)) {
        mysqli_stmt_close($stmt);

        // Fetch the slug associated with the updated product
        $fetchSlugSql = "SELECT slug FROM products WHERE id = ?";
        $stmtSlug = mysqli_prepare($con, $fetchSlugSql);
        mysqli_stmt_bind_param($stmtSlug, "i", $productId);
        mysqli_stmt_execute($stmtSlug);
        mysqli_stmt_bind_result($stmtSlug, $slug);
        mysqli_stmt_fetch($stmtSlug);
        mysqli_stmt_close($stmtSlug);

        // Redirect to the product page using the slug
        header("Location: ../product.php?product=$slug");
        exit();
    } else {
        echo "Failed to update product.";
    }
} else {
    echo "Invalid request method.";
}
