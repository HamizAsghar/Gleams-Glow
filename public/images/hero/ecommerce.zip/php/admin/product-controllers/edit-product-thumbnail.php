<?php
require('../connection.php');

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["updateThumbnailForm"])) {
    // Check if a new thumbnail image is uploaded
    if (isset($_FILES['thumbnail_image']) && $_FILES['thumbnail_image']['error'] === UPLOAD_ERR_OK) {
        // Get product ID
        $productId = $_POST['productId'];

        // Fetch the slug of the product
        $sql_select_slug = "SELECT slug FROM products WHERE id = ?";
        $stmt_select_slug = mysqli_prepare($con, $sql_select_slug);
        mysqli_stmt_bind_param($stmt_select_slug, "i", $productId);
        mysqli_stmt_execute($stmt_select_slug);
        mysqli_stmt_store_result($stmt_select_slug);
        mysqli_stmt_bind_result($stmt_select_slug, $slug);
        mysqli_stmt_fetch($stmt_select_slug);

        // Delete the old thumbnail image file
        // Fetch the old thumbnail image path
        $sql_select_thumbnail = "SELECT thumbnail_image FROM products WHERE id = ?";
        $stmt_select_thumbnail = mysqli_prepare($con, $sql_select_thumbnail);
        mysqli_stmt_bind_param($stmt_select_thumbnail, "i", $productId);
        mysqli_stmt_execute($stmt_select_thumbnail);
        mysqli_stmt_store_result($stmt_select_thumbnail);
        mysqli_stmt_bind_result($stmt_select_thumbnail, $oldThumbnail);
        mysqli_stmt_fetch($stmt_select_thumbnail);

        // Delete the old thumbnail image file
        if (unlink("../../assets/uploads/thumbnails/$oldThumbnail")) {
            // Thumbnail image deleted successfully
            // Handle the new thumbnail image upload
            $newThumbnail = uniqid() . '_' . $_FILES['thumbnail_image']['name'];
            $newThumbnail_temp = $_FILES['thumbnail_image']['tmp_name'];
            move_uploaded_file($newThumbnail_temp, "../../assets/uploads/thumbnails/$newThumbnail");

            // Update the thumbnail image path in the database
            $sql_update_thumbnail = "UPDATE products SET thumbnail_image = ? WHERE id = ?";
            $stmt_update_thumbnail = mysqli_prepare($con, $sql_update_thumbnail);
            mysqli_stmt_bind_param($stmt_update_thumbnail, "si", $newThumbnail, $productId);
            mysqli_stmt_execute($stmt_update_thumbnail);

            // Close statement
            mysqli_stmt_close($stmt_update_thumbnail);
        } else {
            // Error deleting old thumbnail image
            echo "Error deleting old thumbnail image";
        }

        // Close statement
        mysqli_stmt_close($stmt_select_thumbnail);

        // Close statement
        mysqli_stmt_close($stmt_select_slug);
    } else {
        // No new thumbnail image uploaded
        echo "No new thumbnail image uploaded";
    }
} else {
    // Invalid request
    echo "Invalid request";
}

// Redirect back to the product page
header("Location: ../product.php?product=$slug");
exit();
