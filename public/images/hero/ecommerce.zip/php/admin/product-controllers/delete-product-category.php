<?php
require('../connection.php');

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["productId"]) && isset($_POST["categoryId"])) {
    // Get product ID and category ID from the form
    $productId = $_POST["productId"];
    $categoryId = $_POST["categoryId"];

    // Fetch product slug from the database
    $sql = "SELECT slug FROM products WHERE id = ?";
    $stmt = mysqli_prepare($con, $sql);
    mysqli_stmt_bind_param($stmt, "i", $productId);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $slug);
    mysqli_stmt_fetch($stmt);
    mysqli_stmt_close($stmt);

    // Delete from product_categories table
    $sql_delete = "DELETE FROM product_categories WHERE product_id = ? AND category_id = ?";
    $stmt_delete = mysqli_prepare($con, $sql_delete);

    // Bind parameters and execute the statement
    mysqli_stmt_bind_param($stmt_delete, "ii", $productId, $categoryId);
    if (mysqli_stmt_execute($stmt_delete)) {
        // Category deleted successfully
        header("Location: ../product.php?product=$slug");
        exit();
    } else {
        // Error deleting category
        echo "Error: " . mysqli_error($con);
    }

    // Close statement
    mysqli_stmt_close($stmt_delete);
}
