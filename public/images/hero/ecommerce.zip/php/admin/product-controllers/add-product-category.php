<?php
require('../connection.php');

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["productId"]) && isset($_POST["newCategory"])) {
    $productId = $_POST["productId"];
    $newCategoryId = $_POST["newCategory"];

    $sql = "INSERT INTO product_categories (product_id, category_id) VALUES (?, ?)";
    $stmt = mysqli_prepare($con, $sql);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "ii", $productId, $newCategoryId);
        if (mysqli_stmt_execute($stmt)) {
            mysqli_stmt_close($stmt);
            $slug = getSlug($productId, $con);
            header("Location: ../product.php?product=$slug");
            exit();
        } else {
            echo "Error: " . mysqli_error($con);
        }
    } else {
        echo "Error: " . mysqli_error($con);
    }
} else {
    echo "Invalid request";
}

function getSlug($productId, $connection)
{
    $sql = "SELECT slug FROM products WHERE id = ?";
    $stmt = mysqli_prepare($connection, $sql);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "i", $productId);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_bind_result($stmt, $slug);
        mysqli_stmt_fetch($stmt);
        mysqli_stmt_close($stmt);
        return $slug;
    } else {
        echo "Error: " . mysqli_error($connection);
    }
}
