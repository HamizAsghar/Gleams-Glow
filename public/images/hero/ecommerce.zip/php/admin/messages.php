<?php include("./layout.php"); ?>
<?php require('connection.php'); ?>

<?php
if (isset($_POST['delete_message'])) {
    $messageId = $_POST['message_id'];
    $deleteSql = "DELETE FROM contactus WHERE id = $messageId";
    $deleteResult = mysqli_query($con, $deleteSql);

    if ($deleteResult) {
        echo "<div class='alert alert-success' role='alert'>
        Message deleted successfully
      </div>";
    } else {
        echo "<script>alert('Error deleting message');</script>";
    }
}
?>

<section>
    <h3 class="text-center">MESSAGES</h3>
    <div class="container">
        <div class="row">
            <div class="col-md-10 offset-md-1">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Number</th>
                            <th>Message</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $limit = 15;
                        $page = isset($_GET['page']) ? $_GET['page'] : 1;
                        $offset = ($page - 1) * $limit;

                        // Fetch total number of messages
                        $sql_total = "SELECT COUNT(*) AS total FROM contactus";
                        $result_total = mysqli_query($con, $sql_total);
                        $row_total = mysqli_fetch_assoc($result_total);
                        $total_messages = $row_total['total'];

                        $total_pages = ceil($total_messages / $limit);

                        $sql = "SELECT * FROM contactus ORDER BY id DESC LIMIT $limit OFFSET $offset";
                        $result = mysqli_query($con, $sql);

                        if ($result && mysqli_num_rows($result) > 0) {
                            $count = ($page - 1) * $limit + 1;
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<tr>";
                                echo "<td>" . $count++ . "</td>";
                                echo "<td>" . $row['fullname'] . "</td>";
                                echo "<td>" . $row['phonenumber'] . "</td>";
                                echo "<td><button type='button' class='btn btn-link view-message text-black py-0' onclick='showMessage(\"" . $row['fullname'] . "\", \"" . $row['phonenumber'] . "\", \"" . str_replace(array("\r", "\n"), '', $row['usermessage']) . "\")'>View</button></td>";
                                echo "<td><form method='post' style='display: inline;'>
                                              <input type='hidden' name='message_id' value='" . $row['id'] . "'>
                                              <button type='submit' name='delete_message' class='btn btn-link text-danger py-0'>Delete</button>
                                          </form></td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='4'>No messages found</td></tr>";
                        }
                        ?>

                    </tbody>
                </table>
                <div>
                    <nav aria-label="Page navigation example">
                        <ul class="pagination">
                            <li class="page-item <?php echo ($page == 1) ? 'disabled' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo ($page - 1); ?>" aria-label="Previous">
                                    <span aria-hidden="true">&laquo;</span>
                                </a>
                            </li>
                            <?php for ($i = 1; $i <= $total_pages; $i++) : ?>
                                <li class="page-item <?php echo ($page == $i) ? 'active' : ''; ?>">
                                    <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                                </li>
                            <?php endfor; ?>
                            <li class="page-item <?php echo ($page == $total_pages) ? 'disabled' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo ($page + 1); ?>" aria-label="Next">
                                    <span aria-hidden="true">&raquo;</span>
                                </a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Message Modal -->
<div class="modal fade" id="messageModal" tabindex="-1" role="dialog" aria-labelledby="messageModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="messageModalLabel">Message Details</h5>
            </div>
            <div class="modal-body">
                <p><strong class="pe-2">Name:</strong> <span id="messageFullName"></span></p>
                <p><strong class="pe-2">Number:</strong> <span id="messagePhoneNumber"></span></p>
                <p><strong class="pe-2">Message:</strong> <span id="messageText"></span></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeMessageModal()">Close</button>
            </div>
        </div>
    </div>
</div>

<script>
    function showMessage(fullName, phoneNumber, message) {
        document.getElementById('messageFullName').textContent = fullName;
        document.getElementById('messagePhoneNumber').textContent = phoneNumber;
        document.getElementById('messageText').textContent = message;
        document.getElementById('messageModal').classList.add('show');
        document.getElementById('messageModal').style.display = 'block';
        document.body.classList.add('modal-open');
    }

    function closeMessageModal() {
        document.getElementById('messageModal').classList.remove('show');
        document.getElementById('messageModal').style.display = 'none';
        document.body.classList.remove('modal-open');
    }
</script>

<?php include("./layout-end.php"); ?>

<script>
    document.getElementById('deleteMessageBtn').addEventListener('click', function() {
        var messageId = document.querySelector('#messageModal').getAttribute('data-id');
        if (confirm('Are you sure you want to delete this message?')) {
            deleteMessage(messageId);
        }
    });

    // Function to delete a message
    function deleteMessage(messageId) {
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function() {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                if (xhr.status === 200) {
                    $('#messageModal').modal('hide');
                    location.reload();
                } else {
                    console.error('Error deleting message');
                }
            }
        };
        xhr.open('DELETE', 'delete_message.php?id=' + messageId);
        xhr.send();
    }
</script>