<?php
include("./layout.php");
require('connection.php');

if (isset($_GET['product'])) {
    $product_identifier = $_GET['product'];
    if (is_numeric($product_identifier)) {
        $sql = "SELECT * FROM products WHERE id = ?";
    } else {
        $sql = "SELECT * FROM products WHERE slug = ?";
    }
    $stmt = mysqli_prepare($con, $sql);
    mysqli_stmt_bind_param($stmt, "s", $product_identifier);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if (mysqli_num_rows($result) == 1) {
        $product = mysqli_fetch_assoc($result);
    } else {
        header('Location: 404.php');
        exit();
    }
} else {
    header('Location: 404.php');
    exit();
}

?>

<section class="pb-4">
    <h3 class="text-center">EDIT PRODUCT</h3>

    <h5 class="mt-3">Update Title:</h5>
    <form class="add_product_form mt-2" action="product-controllers/edit-product-title.php" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="productId" value="<?php echo $product['id']; ?>">
        <div>
            <label for="newTitle">New Title:</label>
            <input type="text" name="newTitle" id="newTitle" value="<?php echo $product['title']; ?>" required />
        </div>
        <div class="d-flex h-100 justify-content-end"><button class="btn btn-dark" type="submit" name="updateTitleForm">UPDATE TITLE</button></div>
    </form>

    <h5 class="mt-3">Update Details:</h5>
    <form class="add_product_form mt-2" action="product-controllers/edit-product.php" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="productId" value="<?php echo $product['id']; ?>">
        <div>
            <label for="description">Description</label>
            <textarea name="description" id="description" required><?php echo $product['description']; ?></textarea>
        </div>
        <div>
            <label for="price">Price</label>
            <input type="number" name="price" id="price" value="<?php echo $product['price']; ?>" min="0" step="1" required />
        </div>
        <div>
            <label for="discounted_price">Discounted Price</label>
            <input type="number" name="discounted_price" id="discounted_price" value="<?php echo $product['discounted_price']; ?>" min="0" step="1" required />
        </div>
        <div>
            <label for="discounted_percentage">Discounted Percentage</label>
            <input type="number" name="discounted_percentage" id="discounted_percentage" value="<?php echo $product['discounted_percentage']; ?>" min="0" max="100" required />
        </div>
        <div>
            <label for="pieces">Pieces</label>
            <select name="pieces" id="pieces" required>
                <option value="" disabled>Select Piece</option>
                <option value="0" <?php echo ($product['pieces'] == '0') ? 'selected' : ''; ?>>None</option>
                <option value="2" <?php echo ($product['pieces'] == '2') ? 'selected' : ''; ?>>2 Piece</option>
                <option value="3" <?php echo ($product['pieces'] == '3') ? 'selected' : ''; ?>>3 Piece</option>
            </select>
        </div>
        <div>
            <label for="type">Type</label>
            <select name="type" id="type" required>
                <option value="" disabled>Select Type</option>
                <option value="0" <?php echo ($product['type'] == '0') ? 'selected' : ''; ?>>None</option>
                <option value="1" <?php echo ($product['type'] == '1') ? 'selected' : ''; ?>>DYED W/O EMBROIDERED</option>
                <option value="2" <?php echo ($product['type'] == '2') ? 'selected' : ''; ?>>DYED+EMBROIDERED</option>
                <option value="3" <?php echo ($product['type'] == '3') ? 'selected' : ''; ?>>PASTED+EMBROIDERED</option>
                <option value="4" <?php echo ($product['type'] == '4') ? 'selected' : ''; ?>>PASTED+PRINTED</option>
                <option value="5" <?php echo ($product['type'] == '5') ? 'selected' : ''; ?>>PRINTED W/O EMBROIDERED</option>
                <option value="6" <?php echo ($product['type'] == '6') ? 'selected' : ''; ?>>PRINTED+EMBROIDERED</option>
            </select>
        </div>
        <div class="form-check d-flex align-items-center flex-row gap-2">
            <input class="form-check-input" type="checkbox" name="home_page" id="home_page" value="1" <?php if ($product['home_page']) echo 'checked'; ?>>
            <label class="form-check-label" for="home_page">Display on Home Page</label>
        </div>
        <div class="form-check d-flex align-items-center flex-row gap-2">
            <input class="form-check-input" type="checkbox" name="best_selling" id="best_selling" value="1" <?php if ($product['best_selling']) echo 'checked'; ?>>
            <label class="form-check-label" for="best_selling">Best Selling</label>
        </div>
        <div><button class="btn btn-dark" type="submit">UPDATE DETAILS</button></div>
    </form>

    <h5 class="mt-3">Update Thumbnail:</h5>
    <form class="add_product_form mt-2" action="product-controllers/edit-product-thumbnail.php" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="productId" value="<?php echo $product['id']; ?>">
        <div>
            <label for="thumbnail_image">New Thumbnail Image:</label>
            <input type="file" name="thumbnail_image" id="thumbnail_image" required accept="image/*" />
        </div>
        <div class="d-flex h-100 justify-content-end"><button class="btn btn-dark" type="submit" name="updateThumbnailForm">UPDATE THUMBNAIL</button></div>
        <div><label>Old Thumbnail Image:</label><img src="../assets/uploads/thumbnails/<?php echo $product['thumbnail_image']; ?>" width="100px" alt="Product" style="border-radius: 5px"></div>
    </form>

    <h5 class="mt-3">Existing Categories:</h5>
    <div class="mt-2">
        <?php
        $productId = $product['id'];
        $sql = "SELECT pc.category_id, c.category_name FROM product_categories pc JOIN categories c ON pc.category_id = c.id WHERE pc.product_id = ?";
        $stmt = mysqli_prepare($con, $sql);
        mysqli_stmt_bind_param($stmt, "s", $productId);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if (mysqli_num_rows($result) > 0) {
            echo "<div class='edit_product_category'>";
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<div>
                <div>{$row['category_name']}</div> 
                <div>
                    <form action='product-controllers/delete-product-category.php' method='POST'>
                        <input type='hidden' name='productId' value='$productId'>
                        <input type='hidden' name='categoryId' value='{$row['category_id']}'>
                        <button type='submit' class='btn p-0'>
                            <svg aria-hidden='true' xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='none' viewBox='0 0 24 24'>
                                <path stroke='currentColor' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M5 7h14m-9 3v8m4-8v8M10 3h4a1 1 0 0 1 1 1v3H9V4a1 1 0 0 1 1-1ZM6 7h12v13a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V7Z'/>
                            </svg>
                        </button>
                    </form>
                </div>
            </div>";
            }
            echo "</div>";
        } else {
            echo "No categories found.";
        }
        ?>
    </div>

    <h5 class="mt-3">Add New Category:</h5>
    <form class="add_product_form mt-2" action="product-controllers/add-product-category.php" method="POST">
        <input type='hidden' name='productId' value=<?php echo $productId; ?>>
        <div>
            <label for="newCategory">Add New Category:</label>
            <select name="newCategory" id="newCategory" required>
                <option value="">Select Category</option>
                <?php
                // Fetch all categories from the database
                $sqlAllCategories = "SELECT id, category_name FROM categories";
                $resultAllCategories = mysqli_query($con, $sqlAllCategories);

                // Fetch categories already associated with the product
                $sqlProductCategories = "SELECT category_id FROM product_categories WHERE product_id = ?";
                $stmtProductCategories = mysqli_prepare($con, $sqlProductCategories);
                mysqli_stmt_bind_param($stmtProductCategories, "i", $productId);
                mysqli_stmt_execute($stmtProductCategories);
                mysqli_stmt_bind_result($stmtProductCategories, $categoryId);

                // Store the category IDs associated with the product
                $productCategoryIds = [];
                while (mysqli_stmt_fetch($stmtProductCategories)) {
                    $productCategoryIds[] = $categoryId;
                }
                mysqli_stmt_close($stmtProductCategories);

                // Display only categories not associated with the product in the select option
                if (mysqli_num_rows($resultAllCategories) > 0) {
                    while ($row = mysqli_fetch_assoc($resultAllCategories)) {
                        if (!in_array($row['id'], $productCategoryIds)) {
                            echo '<option value="' . $row['id'] . '">' . $row['category_name'] . '</option>';
                        }
                    }
                } else {
                    echo '<option value="" disabled>No categories found</option>';
                }
                ?>
            </select>
        </div>
        <div class="d-flex h-100 justify-content-end"><button class="btn btn-dark" type="submit" name="addCategory">ADD CATEGORY</button></div>
    </form>

    <h5 class="mt-3">Existing Variants:</h5>
    <div class="mt-2">
        <?php
        $productId = $product['id'];
        $sql = "SELECT pv.variant_id, v.name 
        FROM product_variants pv 
        JOIN variants v ON pv.variant_id = v.id 
        WHERE pv.product_id = ?";
        $stmt = mysqli_prepare($con, $sql);
        mysqli_stmt_bind_param($stmt, "i", $productId);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if (mysqli_num_rows($result) > 0) {
            echo "<div class='edit_product_variant'>";
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<div>
            <span>{$row['name']}</span>
            <form action='product-controllers/delete-product-variant.php' method='POST'>
                <input type='hidden' name='productId' value='$productId'>
                <input type='hidden' name='variantId' value='{$row['variant_id']}'>
                <button type='submit' class='btn p-0'>
                    <svg aria-hidden='true' xmlns='http://www.w3.org/2000/svg' width='24' height='24' fill='none' viewBox='0 0 24 24'>
                        <path stroke='currentColor' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M5 7h14m-9 3v8m4-8v8M10 3h4a1 1 0 0 1 1 1v3H9V4a1 1 0 0 1 1-1ZM6 7h12v13a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V7Z'/>
                    </svg>
                </button>
            </form>
        </div>";
            }
            echo "</div>";
        } else {
            echo "No variants found.";
        }
        ?>
    </div>



    <h5 class="mt-3">Add New Variant:</h5>
    <form class="add_product_form mt-2" action="product-controllers/add-product-variant.php" method="POST">
        <input type="hidden" name="productId" value="<?php echo $productId; ?>">
        <div>
            <label for="variantId">Select Variant Name:</label>
            <select name="variantId" id="variantId" required>
                <option value="">Select Variant</option>
                <?php
                // Fetch all variants from the database
                $sqlAllVariants = "SELECT id, name FROM variants";
                $resultAllVariants = mysqli_query($con, $sqlAllVariants);

                // Fetch variants already associated with the product
                $sqlProductVariants = "SELECT variant_id FROM product_variants WHERE product_id = ?";
                $stmtProductVariants = mysqli_prepare($con, $sqlProductVariants);
                mysqli_stmt_bind_param($stmtProductVariants, "i", $productId);
                mysqli_stmt_execute($stmtProductVariants);
                mysqli_stmt_bind_result($stmtProductVariants, $variantId);

                // Store the variant IDs associated with the product
                $productVariantIds = [];
                while (mysqli_stmt_fetch($stmtProductVariants)) {
                    $productVariantIds[] = $variantId;
                }
                mysqli_stmt_close($stmtProductVariants);

                // Display only variants not associated with the product in the select option
                if (mysqli_num_rows($resultAllVariants) > 0) {
                    while ($row = mysqli_fetch_assoc($resultAllVariants)) {
                        if (!in_array($row['id'], $productVariantIds)) {
                            echo '<option value="' . $row['id'] . '">' . $row['name'] . '</option>';
                        }
                    }
                } else {
                    echo '<option value="" disabled>No variants found</option>';
                }
                ?>
            </select>
        </div>
        <div class="d-flex h-100 justify-content-end"><button class="btn btn-dark" type="submit" name="addVariant">ADD VARIANT</button></div>
    </form>


    <form action="product-controllers/delete-product.php" method="POST">
        <input type="hidden" name="productId" value="<?php echo $productId; ?>">
        <div class="text-center">
            <button type="submit" class="btn btn-danger px-3 mt-4" onclick="return confirm('Are you sure you want to delete this product?')">DELETE PRODUCT</button>
        </div>
    </form>

</section>

<?php include("./layout-end.php"); ?>