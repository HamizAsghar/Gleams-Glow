<?php include("./layout.php"); ?>
<?php
require('connection.php');
?>

<section>
    <h3 class="text-center">ARRANGE CATEGORIES</h3>
    <section class="table-responsive">
        <table class="table table-striped table-hover">
            <?php
            $sql = "SELECT id, desktop_image_path, mobile_image_path, category_name, arrange FROM categories ORDER BY arrange ASC";
            $result = mysqli_query($con, $sql);

            if (mysqli_num_rows($result) > 0) {
                echo '<tr>
            <th style="vertical-align: middle;">#</th>
            <th style="vertical-align: middle;">Order</th>
            <th style="vertical-align: middle;">Desktop Image</th>
            <th style="vertical-align: middle;">Mobile Image</th>
            <th style="text-align: center; vertical-align: middle;">Title</th>
        </tr>';
                $index = 1;
                while ($row = mysqli_fetch_assoc($result)) {
                    echo '
            <tr class="category w-100" style="min-width: 100%" draggable="true" data-category-id="' . $row['id'] . '">
                <td style="vertical-align: middle;">' . $index++ . '</td>
                <td style="text-align: center; vertical-align: middle;">' . $row['arrange'] . '</td>
                <td style="vertical-align: middle;">
                    <img style="object-fit: cover; width: 100px; aspect-ratio: auto;" src="../assets/uploads/' . basename($row['desktop_image_path']) . '" alt="category">
                </td>
                <td style="vertical-align: middle;">
                    <img style="object-fit: cover; width: 100px; aspect-ratio: auto;" src="../assets/uploads/' . basename($row['mobile_image_path']) . '" alt="category">
                </td>
                <td style="text-align: center; vertical-align: middle;">' . $row['category_name'] . '</td>
            </tr>
            ';
                }
            } else {
                echo '<div class="d-flex justify-content-center align-items-center">No views today.</div>';
            }
            ?>
        </table>
    </section>
    <div class="text-center">
        <button type="button" class="save_button btn btn-dark px-4 rounded-5">SAVE</button>
    </div>
</section>

<script>
    const categories = document.querySelectorAll('.category');
    let draggedItem = null;
    categories.forEach(category => {
        category.addEventListener('dragstart', dragStart);
        category.addEventListener('dragend', dragEnd);
        category.addEventListener('dragover', dragOver);
        category.addEventListener('dragenter', dragEnter);
        category.addEventListener('dragleave', dragLeave);
        category.addEventListener('drop', dragDrop);
    });

    function dragStart() {
        draggedItem = this;
        setTimeout(() => {
            this.style.display = 'none';
        }, 0);
    }

    function dragEnd() {
        setTimeout(() => {
            draggedItem.style.display = '';
            draggedItem = null;
        }, 0);
    }

    function dragOver(e) {
        e.preventDefault();
    }

    function dragEnter(e) {
        e.preventDefault();
        this.style.backgroundColor = 'rgba(0, 0, 0, 0.1)';
    }

    function dragLeave() {
        this.style.backgroundColor = 'transparent';
    }

    function dragDrop() {
        this.style.backgroundColor = 'transparent';
        this.parentNode.insertBefore(draggedItem, this);
    }

    document.querySelector('.save_button').addEventListener('click', function() {
        const categories = document.querySelectorAll('.category');
        const categoryIds = Array.from(categories).map(category => category.dataset.categoryId);
        const newArrangeValues = Array.from(categories).map((category, index) => ({
            id: category.dataset.categoryId,
            arrange: index + 1 // Assign new arrange values based on the new order
        }));

        // Send the new arrangement data to the server via AJAX
        fetch('category-controllers/arrange-categories.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(newArrangeValues)
            })
            .then(response => {
                if (response.ok) {
                    alert('Category arrangement saved successfully.');
                } else {
                    throw new Error('Failed to save category arrangement.');
                }
            })
            .catch(error => {
                console.error('Error saving category arrangement:', error);
                alert('Failed to save category arrangement. Please try again.');
            });
    });
</script>

<?php include("./layout-end.php"); ?>