<?php include("./layout.php"); ?>
<?php
require('connection.php');
?>

<section>
    <h3 class="text-center">ARRANGE PRODUCTS</h3>
    <section class="table-responsive">
        <table class="table table-striped table-hover">
            <?php
            $sql = "SELECT id, thumbnail_image, title, slug, price, discounted_price, home_page, best_selling, arrange FROM products ORDER BY arrange ASC";
            $result = mysqli_query($con, $sql);

            if (mysqli_num_rows($result) > 0) {
                echo '<tr>
            <th style="vertical-align: middle;">#</th>
            <th style="vertical-align: middle;">Image</th>
            <th style="vertical-align: middle;">Title</th>
            <th style="text-align: center; vertical-align: middle;">Price</th>
            <th style="text-align: center; vertical-align: middle;">Arrange</th>
            <th style="text-align: center; vertical-align: middle;">Best Selling</th>
            <th style="text-align: center; vertical-align: middle;">Home Page</th>
        </tr>';
                $index = 1;
                while ($row = mysqli_fetch_assoc($result)) {
                    echo '
            <tr class="product w-100" style="min-width: 100%" draggable="true" data-product-id="' . $row['id'] . '">
                <td style="vertical-align: middle;">' . $index++ . '</td>
                <td style="vertical-align: middle;">
                    <a href="product.php?product=' . $row['slug'] . '">
                        <img style="border-radius: 50%;object-fit: cover;" src="../assets/uploads/thumbnails/' . basename($row['thumbnail_image']) . '" width="50px" height="50px" alt="Product">
                    </a>
                </td>
                <td style="vertical-align: middle;">
                    <a href="product.php?product=' . $row['slug'] . '" style="text-decoration: none; color: black;">
                    ' . $row['title'] . '
                    </a>
                </td>
                <td style="text-align: center; vertical-align: middle;">Rs. ' . ($row['discounted_price'] > 0 ? number_format($row['discounted_price'], 0) : number_format($row['price'], 0)) . '</td>
                <td style="text-align: center; vertical-align: middle;">' . $row['arrange'] . '</td>
                <td style="text-align: center; vertical-align: middle; text-transform: capitalize;">' . $row['best_selling'] . '</td>
                <td style="text-align: center; vertical-align: middle; text-transform: capitalize;">' . $row['home_page'] . '</td>
            </tr>
            ';
                }
            } else {
                echo '<div class="d-flex justify-content-center align-items-center">No views today.</div>';
            }
            ?>
        </table>
    </section>
    <div class="text-center">
        <button type="button" class="save_button btn btn-dark px-4 rounded-5">SAVE</button>
    </div>
</section>

<script>
    const products = document.querySelectorAll('.product');
    let draggedItem = null;
    products.forEach(product => {
        product.addEventListener('dragstart', dragStart);
        product.addEventListener('dragend', dragEnd);
        product.addEventListener('dragover', dragOver);
        product.addEventListener('dragenter', dragEnter);
        product.addEventListener('dragleave', dragLeave);
        product.addEventListener('drop', dragDrop);
    });

    function dragStart() {
        draggedItem = this;
        setTimeout(() => {
            this.style.display = 'none';
        }, 0);
    }

    function dragEnd() {
        setTimeout(() => {
            draggedItem.style.display = '';
            draggedItem = null;
        }, 0);
    }

    function dragOver(e) {
        e.preventDefault();
    }

    function dragEnter(e) {
        e.preventDefault();
        this.style.backgroundColor = 'rgba(0, 0, 0, 0.1)';
    }

    function dragLeave() {
        this.style.backgroundColor = 'transparent';
    }

    function dragDrop() {
        this.style.backgroundColor = 'transparent';
        this.parentNode.insertBefore(draggedItem, this);
    }

    document.querySelector('.save_button').addEventListener('click', function() {
        const products = document.querySelectorAll('.product');
        const productIds = Array.from(products).map(product => product.dataset.productId);
        const newArrangeValues = Array.from(products).map((product, index) => ({
            id: product.dataset.productId,
            arrange: index + 1 // Assign new arrange values based on the new order
        }));

        // Send the new arrangement data to the server via AJAX
        fetch('product-controllers/update_product_arrange.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(newArrangeValues)
            })
            .then(response => {
                if (response.ok) {
                    alert('Product arrangement saved successfully.');
                } else {
                    throw new Error('Failed to save product arrangement.');
                }
            })
            .catch(error => {
                console.error('Error saving product arrangement:', error);
                alert('Failed to save product arrangement. Please try again.');
            });
    });
</script>

<?php include("./layout-end.php"); ?>