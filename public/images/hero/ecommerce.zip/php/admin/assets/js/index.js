// Delete Banner
$(document).ready(function () {
  $(".admin_banner_del_btn").click(function () {
    var bannerId = $(this).closest(".admin_banner_container").data("banner-id");
    if (confirm("Are you sure you want to delete this banner?")) {
      $.ajax({
        type: "POST",
        url: "./banner-controllers/delete-banner.php",
        data: {
          banner_id: bannerId,
        },
        success: function (response) {
          console.log("Success!");
          console.log(response);
        },
        error: function (xhr, status, error) {
          console.error(xhr.responseText);
          console.error(error);
          alert("An error occurred while deleting the banner.");
        },
      });
    }
  });
});


// Delete Category
$(document).ready(function () {
  $(".admin_category_del_btn").click(function () {
    var categoryId = $(this).closest(".admin_category_container").data("category-id");
    if (confirm("Are you sure you want to delete this category?")) {
      $.ajax({
        type: "POST",
        url: "./category-controllers/delete-category.php", // PHP script to handle deletion
        data: {
          category_id: categoryId,
        },
        success: function (response) {
          console.log("Success!"); // Debug message
          console.log(response); // Debug message
          // Refresh the page or update the category list as needed
          // location.reload();
        },
        error: function (xhr, status, error) {
          console.error(xhr.responseText);
          console.error(error); // Log the specific error message
          alert("An error occurred while deleting the category.");
        },
      });
    }
  });
});